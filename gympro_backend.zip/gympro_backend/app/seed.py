"""Bootstrap the first admin: ADMIN_EMAIL=... ADMIN_PASSWORD=... python -m app.seed"""
import asyncio, os, sys
from sqlalchemy import text
from .auth import hash_pw
from .db import engine


async def main():
    email, pw = os.environ.get("ADMIN_EMAIL"), os.environ.get("ADMIN_PASSWORD")
    if not email or not pw or len(pw) < 12:
        sys.exit("Set ADMIN_EMAIL and ADMIN_PASSWORD (min 12 chars)")
    async with engine.begin() as c:
        r = await c.execute(text("insert into users (email, password_hash, full_name, role) values (:e,:h,'Administrator','ADMIN') on conflict (email) do nothing returning id"),
                            {"e": email, "h": await hash_pw(pw)})
        print("admin created" if r.first() else "admin already exists")


asyncio.run(main())
