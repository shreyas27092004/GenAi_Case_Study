from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Literal

DEFAULT_SECRET = "change-me-in-production-0123456789abcdef"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    env: str = "dev"
    database_url: str = "postgresql+asyncpg://gympro_app:gympro_app@localhost:5432/gympro"
    jwt_secret: str = DEFAULT_SECRET
    jwt_alg: str = "HS256"
    jwt_ttl_min: int = 60
    llm_provider: Literal["none", "azure", "openai", "ollama"] = "none"
    llm_model: str = "gpt-4o"
    llm_api_key: str = "ollama"
    llm_base_url: str | None = "http://localhost:11434/v1"
    azure_endpoint: str | None = None
    azure_api_version: str = "2024-10-21"
    agent_max_tool_steps: int = 6
    agent_timeout_s: float = 25.0
    run_token_budget: int = 20000
    cors_origins: str = "http://localhost:5173"

    def assert_production_safe(self):
        if self.env == "production" and (self.jwt_secret == DEFAULT_SECRET or len(self.jwt_secret) < 32):
            raise RuntimeError("Refusing to start in production with a default/weak JWT secret")


settings = Settings()
