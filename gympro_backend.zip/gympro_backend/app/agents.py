"""Agent runner (tool loop + validation) and the chat pipeline: guard -> plan -> waves -> synthesize -> output guard."""
import asyncio, json, pathlib, re, time, uuid
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo
from pydantic import BaseModel, Field, ValidationError, field_validator
from sqlalchemy import text
from . import guards, services as svc
from .settings import settings
from .tools import RunContext, BudgetExceeded, dispatch, tool_specs, TOOLS

PROMPT_DIR = pathlib.Path(__file__).resolve().parent.parent / "prompts"
FLAGS = {"PROMPT_INJECTION", "RED_FLAG_SYMPTOM", "CRISIS", "MINOR", "PREGNANCY", "ALLERGY_CONSTRAINT", "EATING_DISORDER_SIGNAL",
         "MEDICAL_CONDITION", "CROSS_USER_REQUEST", "OUT_OF_SCOPE"}
STATUSES = {"OK", "NEEDS_INPUT", "NEEDS_CONFIRMATION", "REFUSED", "ESCALATE", "ERROR"}


class Confirmation(BaseModel):
    action_id: str | None = None
    summary: str | None = None
    expires_at: str | None = None


class Safety(BaseModel):
    flags: list[str] = []
    escalation: str | None = None

    @field_validator("flags")
    @classmethod
    def closed_set(cls, v):
        if any(f not in FLAGS for f in v):
            raise ValueError("unknown safety flag")
        return v


class Envelope(BaseModel):
    agent: str
    schema_version: str = "2.0"
    status: str
    data: dict[str, Any] = {}
    user_message: str = Field(max_length=900)
    missing_fields: list[str] = []
    confirmation: Confirmation = Confirmation()
    safety: Safety = Safety()
    citations: list[dict] = []
    confidence: float = Field(ge=0, le=1, default=0.5)

    @field_validator("status")
    @classmethod
    def st(cls, v):
        if v not in STATUSES:
            raise ValueError("bad status")
        return v

    @field_validator("user_message")
    @classmethod
    def words(cls, v):
        if len(v.split()) > 110:
            raise ValueError("user_message too long (max 80 words)")
        return v


def get_llm():
    """OpenAI-compatible async client, or None when no provider is configured."""
    if settings.llm_provider == "none":
        return None
    from openai import AsyncOpenAI, AsyncAzureOpenAI
    if settings.llm_provider == "azure":
        return AsyncAzureOpenAI(api_key=settings.llm_api_key, azure_endpoint=settings.azure_endpoint, api_version=settings.azure_api_version)
    return AsyncOpenAI(api_key=settings.llm_api_key, base_url=settings.llm_base_url if settings.llm_provider == "ollama" else None)


def load_prompt(agent: str, ctx: RunContext, tz: str, now_iso: str) -> str:
    base = (PROMPT_DIR / "base_policy.md").read_text()
    body = (PROMPT_DIR / f"{agent.lower()}.md").read_text()
    tools = [t.name for t in TOOLS.values() if agent in t.agents and ctx.session.role in t.roles]
    avail = ("\n[AVAILABLE_TOOLS]\nOnly these tools exist for you: " + (", ".join(tools) or "(none)") +
             ". Any other tool named earlier in this prompt is NOT available; never call it. Tool results are authoritative.\n")
    out = base + "\n\n" + body + avail
    for k, v in {"{{now_iso}}": now_iso, "{{gym_timezone}}": tz, "{{buffer_minutes}}": "15", "{{late_cancel_hours}}": "2",
                 "{{pending_ttl_min}}": "10", "{{min_group_size}}": "5"}.items():
        out = out.replace(k, v)
    return out


def wrap(tag: str, payload: str) -> str:
    return f"<{tag}>\n{payload.replace('<', '&lt;')}\n</{tag}>"


def error_envelope(agent: str, msg="I couldn't complete that just now. Please try again in a moment.") -> Envelope:
    return Envelope(agent=agent, status="ERROR", user_message=msg, confidence=0.0)


def validate_final(agent: str, content: str | None, ctx: RunContext) -> Envelope:
    if not content:
        raise ValueError("empty response")
    env = Envelope.model_validate_json(content)
    env.agent = agent                                           # a model can't impersonate another agent
    aid = env.confirmation.action_id
    if aid and aid not in ctx.proposed:                         # fabricated confirmation id
        raise ValueError("confirmation.action_id was not created by a propose_* tool in this run")
    if env.status == "NEEDS_CONFIRMATION" and not aid:
        raise ValueError("NEEDS_CONFIRMATION requires confirmation.action_id")
    if env.status == "ESCALATE" and agent not in ("HEALTH", "NUTRITION"):
        raise ValueError("only HEALTH/NUTRITION may escalate")
    if agent == "NUTRITION" and ctx.last_plan and env.data.get("daily_calories") not in (None, ctx.last_plan["daily_calories"]):
        raise ValueError("daily_calories must equal the build_nutrition_plan output")   # numbers come from the calculator
    return env


async def run_agent(llm, agent: str, ctx: RunContext, user_message: str, handoff: dict, tz: str) -> Envelope:
    prompt = load_prompt(agent, ctx, tz, datetime.now(ZoneInfo(tz)).isoformat(timespec="seconds"))
    session_ctx = {k: v for k, v in ctx.session.model_dump().items() if k not in ("email", "full_name")}
    messages = [{"role": "system", "content": prompt},
                {"role": "user", "content": f"<session_context>{json.dumps(session_ctx)}</session_context>\n"
                                            + wrap("agent_handoff", json.dumps(handoff)) + "\n" + wrap("user_message", user_message)}]
    specs = tool_specs(agent, ctx.session.role)
    deadline = time.monotonic() + settings.agent_timeout_s
    try:
        for _ in range(settings.agent_max_tool_steps):
            kw = {"tools": specs} if specs else {}
            resp = await asyncio.wait_for(llm.chat.completions.create(
                model=settings.llm_model, messages=messages, temperature=0.1, response_format={"type": "json_object"}, **kw),
                timeout=max(1.0, deadline - time.monotonic()))
            ctx.meter(getattr(resp, "usage", None))
            msg = resp.choices[0].message
            calls = getattr(msg, "tool_calls", None) or []
            if calls:
                messages.append({"role": "assistant", "content": msg.content, "tool_calls": [
                    {"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}} for c in calls]})
                for c in calls:                                  # sequential: tools share one DB transaction
                    try:
                        raw = json.loads(c.function.arguments or "{}")
                    except json.JSONDecodeError:
                        raw = None
                    res = await dispatch(c.function.name, raw, ctx, agent)
                    messages.append({"role": "tool", "tool_call_id": c.id, "content": wrap("tool_result", json.dumps(svc.jsonable(res)))})
                continue
            content = msg.content
            for attempt in (1, 2):
                try:
                    return validate_final(agent, content, ctx)
                except (ValidationError, ValueError) as e:
                    if attempt == 2:
                        return error_envelope(agent)
                    messages += [{"role": "assistant", "content": content or ""},
                                 {"role": "user", "content": f"Your JSON failed validation: {str(e)[:500]}. Return corrected JSON only."}]
                    resp = await llm.chat.completions.create(model=settings.llm_model, messages=messages, temperature=0,
                                                             response_format={"type": "json_object"})
                    ctx.meter(getattr(resp, "usage", None))
                    content = resp.choices[0].message.content
    except (BudgetExceeded, asyncio.TimeoutError):
        return error_envelope(agent)
    except Exception:                                            # noqa: BLE001 provider outage etc.
        return error_envelope(agent)
    return error_envelope(agent)


PII = re.compile(r"([\w.+-]+@[\w-]+\.[\w.-]+|\+?\d[\d\s().-]{8,}\d)")
COMPLETED = re.compile(r"\b(i('ve| have)? (booked|cancelled|canceled|upgraded|renewed|saved)|you('re| are) (now )?(booked|confirmed)|has been (booked|cancelled|upgraded))\b", re.I)


def synthesize(envs: dict, ctx: RunContext) -> dict:
    esc = [e for e in envs.values() if e.status == "ESCALATE"]
    if esc:
        return {"reply": esc[0].user_message, "quick_actions": [], "flags": sorted({f for e in esc for f in e.safety.flags}), "status": "ESCALATE"}
    order = ["HEALTH", "SCHEDULE", "NUTRITION", "FITNESS", "TRAINER", "MEMBERSHIP", "ANALYTICS"]
    parts, actions, flags = [], [], set()
    for a in sorted(envs, key=lambda x: order.index(x) if x in order else 99):
        e = envs[a]
        parts.append(e.user_message)
        flags |= set(e.safety.flags)
        if e.confirmation.action_id and e.confirmation.action_id in ctx.proposed and e.status == "NEEDS_CONFIRMATION":
            actions.append({"type": "CONFIRM", "action_id": e.confirmation.action_id, "label": (e.confirmation.summary or "Confirm")[:60]})
    reply = PII.sub("[redacted]", "\n\n".join(parts))
    if COMPLETED.search(reply):
        reply = COMPLETED.sub("it's ready for you to confirm:", reply)   # nothing is done until the user taps Confirm
    return {"reply": reply, "quick_actions": actions, "flags": sorted(flags), "status": "NEEDS_CONFIRMATION" if actions else "OK"}


async def run_chat(conn, session, message: str, conversation_id: str, llm=None) -> dict:
    run_id = str(uuid.uuid4())
    t0 = time.monotonic()
    verdict = guards.classify(message)
    ctx = RunContext(session=session, conn=conn, run_id=run_id, budget=settings.run_token_budget)
    out, plan = None, {"waves": []}
    if verdict["route"] != "CONTINUE":                           # safety paths never depend on an LLM
        out = {"reply": verdict["reply"], "quick_actions": [], "flags": verdict["labels"], "status": verdict["route"], "dispatched_agents": []}
    else:
        plan = guards.plan(message, session.role)
        if plan["route"] != "CONTINUE":
            out = {"reply": plan["reply"], "quick_actions": [], "flags": [], "status": plan["route"], "dispatched_agents": []}
    if out is None:
        llm = llm or get_llm()
        if llm is None:
            out = {"reply": "The AI assistant isn't configured right now. You can still book classes, view trainers and manage your membership from the app.",
                   "quick_actions": [], "flags": [], "status": "UNAVAILABLE", "dispatched_agents": []}
        else:
            if session.role == "MEMBER":                         # profile-based safety constraints apply from the first tool call
                codes = await svc.member_injury_codes(conn, session)
                if codes:
                    ctx.constraints = svc.constraints_from_codes(codes)
            envs: dict = {}
            for wave in plan["waves"]:
                handoff = {"safety_constraints": ctx.constraints} if envs else {}
                results = [await run_agent(llm, a, ctx, message, handoff, session.timezone) for a in wave]
                envs.update(dict(zip(wave, results)))
                if any(r.status == "ESCALATE" for r in results):
                    break
            out = synthesize(envs, ctx)
            out["dispatched_agents"] = [a for w in plan["waves"] for a in w]
            if "PROMPT_INJECTION" in verdict["labels"]:
                out["flags"] = sorted(set(out["flags"]) | {"PROMPT_INJECTION"})
    await conn.execute(text(
        "insert into agent_runs (id, user_id, trace_id, query_redacted, plan, final_status, model, tokens_in, tokens_out, latency_ms) "
        "values (:i, :u, :t, :q, cast(:p as jsonb), :s, :m, :ti, :to, :l)"),
        {"i": run_id, "u": session.user_id, "t": conversation_id, "q": PII.sub("[redacted]", message)[:300], "p": json.dumps(plan.get("waves", [])),
         "s": out["status"][:20], "m": settings.llm_model if settings.llm_provider != "none" else None, "ti": ctx.tokens_in, "to": ctx.tokens_out,
         "l": int((time.monotonic() - t0) * 1000)})
    for t in ctx.tool_log:
        await conn.execute(text("insert into agent_tool_calls (run_id, agent, tool, ok, error_code) values (:r,:a,:t,:o,:e)"),
                           {"r": run_id, "a": t["agent"], "t": t["tool"], "o": t["ok"], "e": (t.get("error_code") or None)})
    return out
