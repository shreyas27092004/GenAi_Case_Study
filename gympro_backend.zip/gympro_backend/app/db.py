import json
from contextlib import asynccontextmanager
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncConnection
from .settings import settings

engine = create_async_engine(settings.database_url, pool_size=10, max_overflow=20, pool_pre_ping=True)


async def set_ctx(conn: AsyncConnection, user_id: str | None, role: str | None):
    """Transaction-local RLS context. set_config(..., true) cannot leak across pooled connections."""
    await conn.execute(text("select set_config('app.user_id', :u, true), set_config('app.role', :r, true)"),
                       {"u": user_id or "", "r": role or ""})


@asynccontextmanager
async def as_system(conn: AsyncConnection, restore_user: str, restore_role: str):
    """Server-internal elevation (e.g. promote a waitlisted member). Never reachable from request data."""
    await set_ctx(conn, restore_user, "SYSTEM")
    try:
        yield
    finally:
        await set_ctx(conn, restore_user, restore_role)


async def gym_setting(conn, key: str, default=None):
    r = (await conn.execute(text("select value::text from gym_settings where key=:k"), {"k": key})).scalar()
    return json.loads(r) if r is not None else default
