import json, uuid
from datetime import date, datetime, timedelta, timezone
from typing import Literal
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from . import agents, calc, nutrition, services as svc, tools as T
from .auth import (SessionContext, age_from, get_db, get_session, hash_pw, ip_rate_limit, make_token, rate_limit,
                   require_roles, verify_pw)
from .db import as_system, engine, gym_setting, set_ctx
from .settings import settings

settings.assert_production_safe()
app = FastAPI(title="GymPro Multi-Agent API", version="2.1.0")
app.add_middleware(CORSMiddleware, allow_origins=[o for o in settings.cors_origins.split(",") if o], allow_credentials=False,
                   allow_methods=["GET", "POST", "PUT"], allow_headers=["Authorization", "Content-Type"])


class Body(BaseModel):
    model_config = ConfigDict(extra="forbid")      # unknown fields (e.g. role, user_id) are rejected, not silently ignored


@app.exception_handler(Exception)
async def unhandled(_: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"error": "INTERNAL_ERROR"})   # no stack traces / SQL to clients


@app.get("/health")
async def health():
    async with engine.connect() as c:
        await c.execute(text("select 1"))
    return {"status": "ok"}


# ============================================================ auth
class RegisterBody(Body):
    email: EmailStr
    password: str = Field(min_length=10, max_length=72)
    full_name: str = Field(min_length=1, max_length=100)

    @field_validator("password")
    @classmethod
    def pw(cls, v):
        if len(v.encode()) > 72:
            raise ValueError("password too long")
        if v.lower() == v or not any(ch.isdigit() for ch in v):
            raise ValueError("password needs upper-case letters and digits")
        return v


class LoginBody(Body):
    email: EmailStr
    password: str = Field(min_length=1, max_length=72)


@app.post("/api/auth/register", status_code=201, dependencies=[Depends(ip_rate_limit("register", 10, 60))])
async def register(b: RegisterBody):
    h = await hash_pw(b.password)
    async with engine.begin() as conn:               # role is ALWAYS MEMBER here; elevation only via admin endpoint
        try:
            uid = (await conn.execute(text("insert into users (email, password_hash, full_name, role) values (:e,:h,:n,'MEMBER') returning id"),
                                      {"e": b.email, "h": h, "n": b.full_name.strip()})).scalar()
        except IntegrityError:
            raise HTTPException(409, "Unable to register with these details")
    return {"token": make_token(str(uid)), "user_id": str(uid)}


@app.post("/api/auth/login", dependencies=[Depends(ip_rate_limit("login", 10, 60))])
async def login(b: LoginBody):
    async with engine.connect() as conn:
        row = (await conn.execute(text("select id, password_hash from users where email=:e and is_active and deleted_at is null"), {"e": b.email})).mappings().first()
    ok = await verify_pw(b.password, row["password_hash"] if row else None)
    if not ok:
        raise HTTPException(401, "Invalid credentials")
    return {"token": make_token(str(row["id"]))}


@app.get("/api/me")
async def me(s: SessionContext = Depends(get_session)):
    return {"user_id": s.user_id, "email": s.email, "full_name": s.full_name, "role": s.role, "plan": s.plan,
            "health_consent": s.health_consent, "is_minor": s.is_minor}


# ============================================================ member profile
INJURY_CODES = Literal["KNEE", "LOWER_BACK", "SHOULDER", "ANKLE", "WRIST", "NECK"]


class ProfileBody(Body):
    date_of_birth: date
    gender: Literal["MALE", "FEMALE", "OTHER", "UNSPECIFIED"] = "UNSPECIFIED"
    height_cm: float = Field(ge=100, le=250)
    weight_kg: float = Field(ge=25, le=350)
    experience_level: Literal["BEGINNER", "INTERMEDIATE", "ADVANCED"] = "BEGINNER"
    goal: Literal["FAT_LOSS", "MUSCLE_GAIN", "ENDURANCE", "REHABILITATION", "MAINTENANCE"] = "MAINTENANCE"
    activity_level: Literal["SEDENTARY", "LIGHT", "MODERATE", "VERY_ACTIVE"] = "LIGHT"
    known_injuries: list[INJURY_CODES] = Field(default_factory=list, max_length=6)
    allergies: list[str] = Field(default_factory=list, max_length=10)
    dietary_preference: Literal["VEGAN", "VEGETARIAN", "NONE"] | None = None
    is_pregnant: bool | None = None
    medical_clearance: bool = False
    health_data_consent: bool = False

    @field_validator("date_of_birth")
    @classmethod
    def dob(cls, v):
        if not (12 <= age_from(v) <= 110):
            raise ValueError("age must be between 12 and 110")
        return v

    @field_validator("allergies")
    @classmethod
    def al(cls, v):
        return [a.strip().lower()[:30] for a in v if a.strip()]


@app.put("/api/me/profile")
async def put_profile(b: ProfileBody, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    await conn.execute(text(
        "insert into member_profiles (user_id, date_of_birth, gender, height_cm, weight_kg, experience_level, goal, activity_level, known_injuries, "
        "allergies, dietary_preference, is_pregnant, medical_clearance, health_data_consent_at) "
        "values (:u,:dob,cast(:g as gender_type),:h,:w,cast(:el as fitness_level_type),cast(:go as fitness_goal_type),:al,:inj,:alg,:dp,:pg,:mc, case when :c then now() end) "
        "on conflict (user_id) do update set date_of_birth=excluded.date_of_birth, gender=excluded.gender, height_cm=excluded.height_cm, "
        "weight_kg=excluded.weight_kg, experience_level=excluded.experience_level, goal=excluded.goal, activity_level=excluded.activity_level, "
        "known_injuries=excluded.known_injuries, allergies=excluded.allergies, dietary_preference=excluded.dietary_preference, "
        "is_pregnant=excluded.is_pregnant, medical_clearance=excluded.medical_clearance, updated_at=now(), "
        "health_data_consent_at = case when :c then coalesce(member_profiles.health_data_consent_at, now()) else null end"),
        {"u": s.user_id, "dob": b.date_of_birth, "g": b.gender, "h": b.height_cm, "w": b.weight_kg, "el": b.experience_level, "go": b.goal,
         "al": b.activity_level, "inj": list(b.known_injuries), "alg": b.allergies, "dp": b.dietary_preference, "pg": b.is_pregnant,
         "mc": b.medical_clearance, "c": b.health_data_consent})
    return {"ok": True}


@app.get("/api/me/profile")
async def get_profile(s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    r = (await conn.execute(text(
        "select date_of_birth, gender::text as gender, height_cm, weight_kg, experience_level::text as experience_level, goal::text as goal, activity_level, "
        "known_injuries, allergies, dietary_preference, is_pregnant, medical_clearance, health_data_consent_at from member_profiles where user_id=:u"),
        {"u": s.user_id})).mappings().first()
    if not r:
        raise HTTPException(404, "Profile not found")
    d = svc.jsonable(dict(r))
    d["height_cm"], d["weight_kg"] = float(d["height_cm"]), float(d["weight_kg"])
    return d


# ============================================================ classes
@app.get("/api/classes")
async def classes(category: Literal["HIIT", "YOGA", "PILATES", "SPIN", "STRENGTH", "ZUMBA", "SWIMMING", "RECOVERY"] | None = None,
                  max_impact: Literal["LOW", "MODERATE", "HIGH"] | None = None, date_from: datetime | None = None, date_to: datetime | None = None,
                  limit: int = 25, s: SessionContext = Depends(get_session), conn=Depends(get_db)):
    for d in (date_from, date_to):
        if d and d.tzinfo is None:
            raise HTTPException(422, "date_from/date_to need a timezone offset")
    return {"classes": await svc.list_classes(conn, date_from=date_from, date_to=date_to, category=category, max_impact=max_impact, limit=limit)}


@app.get("/api/classes/{class_id}")
async def class_detail(class_id: uuid.UUID, s: SessionContext = Depends(get_session), conn=Depends(get_db)):
    r = await svc.get_class(conn, class_id)
    if not r:
        raise HTTPException(404, "Class not found")
    return svc.class_view(r)


class ClassBody(Body):
    title: str = Field(min_length=1, max_length=120)
    trainer_id: uuid.UUID | None = None
    category: Literal["HIIT", "YOGA", "PILATES", "SPIN", "STRENGTH", "ZUMBA", "SWIMMING", "RECOVERY"]
    impact: Literal["LOW", "MODERATE", "HIGH"] = "MODERATE"
    contraindicated_for: list[INJURY_CODES] = Field(default_factory=list)
    min_level: Literal["BEGINNER", "INTERMEDIATE", "ADVANCED"] = "BEGINNER"
    est_calories_burned: int = Field(default=300, ge=0, le=2000)
    capacity: int = Field(ge=1, le=200)
    start_time: datetime
    end_time: datetime

    @field_validator("start_time", "end_time")
    @classmethod
    def tz(cls, v):
        if v.tzinfo is None:
            raise ValueError("timezone offset required")
        return v


@app.post("/api/admin/classes", status_code=201)
async def create_class(b: ClassBody, s: SessionContext = Depends(require_roles("ADMIN", "TRAINER")), conn=Depends(get_db)):
    trainer = b.trainer_id if s.role == "ADMIN" and b.trainer_id else uuid.UUID(s.user_id)
    if s.role == "TRAINER" and b.trainer_id and str(b.trainer_id) != s.user_id:
        raise HTTPException(403, "Trainers can only create their own classes")
    if b.start_time <= svc.now_utc() or b.end_time <= b.start_time or b.end_time - b.start_time > timedelta(hours=4):
        raise HTTPException(422, "Invalid time window")
    if not (await conn.execute(text("select 1 from trainer_profiles where trainer_id=:t"), {"t": trainer})).scalar():
        raise HTTPException(422, "Unknown trainer")
    try:
        async with conn.begin_nested():
            cid = (await conn.execute(text(
                "insert into fitness_classes (title, trainer_id, category, impact, contraindicated_for, min_level, est_calories_burned, capacity, start_time, end_time) "
                "values (:t,:tr,cast(:c as class_category),cast(:i as impact_level),:ci,cast(:ml as fitness_level_type),:k,:cap,:s,:e) returning id"),
                {"t": b.title, "tr": trainer, "c": b.category, "i": b.impact, "ci": list(b.contraindicated_for), "ml": b.min_level,
                 "k": b.est_calories_burned, "cap": b.capacity, "s": b.start_time, "e": b.end_time})).scalar()
    except IntegrityError:
        raise HTTPException(409, "Trainer already has a class in that time window")
    return {"class_id": str(cid)}


@app.post("/api/admin/classes/{class_id}/cancel")
async def cancel_class(class_id: uuid.UUID, s: SessionContext = Depends(require_roles("ADMIN")), conn=Depends(get_db)):
    cls = await svc.get_class(conn, class_id, lock=True)
    if not cls or cls["status"] != "SCHEDULED":
        raise HTTPException(404, "Class not found or not cancellable")
    tz = await gym_setting(conn, "timezone", "UTC")
    async with as_system(conn, s.user_id, s.role):
        rows = (await conn.execute(text("select id, user_id from class_bookings where class_id=:c and status in ('CONFIRMED','WAITLISTED') for update"), {"c": cls["id"]})).mappings().all()
        await conn.execute(text("update class_bookings set status='CANCELLED', cancelled_at=now() where class_id=:c and status in ('CONFIRMED','WAITLISTED')"), {"c": cls["id"]})
        for r in rows:
            await svc.enqueue(conn, str(r["user_id"]), "BOOKING_CANCELLED", {"class_title": cls["title"], "when": svc.fmt_local(cls["start_time"], tz)}, f"clscancel:{r['id']}")
    await conn.execute(text("update fitness_classes set status='CANCELLED', booked_count=0 where id=:c"), {"c": cls["id"]})
    return {"ok": True, "bookings_cancelled": len(rows)}


class AttendanceBody(Body):
    user_ids: list[uuid.UUID] = Field(min_length=1, max_length=200)


@app.post("/api/classes/{class_id}/attendance")
async def mark_attendance(class_id: uuid.UUID, b: AttendanceBody, s: SessionContext = Depends(require_roles("ADMIN", "TRAINER")), conn=Depends(get_db)):
    cls = await svc.get_class(conn, class_id)
    if not cls or (s.role == "TRAINER" and str(cls["trainer_id"]) != s.user_id):
        raise HTTPException(404, "Class not found")
    if cls["start_time"] > svc.now_utc():
        raise HTTPException(409, "Class has not started")
    async with as_system(conn, s.user_id, s.role):
        res = await conn.execute(text("update class_bookings set status='ATTENDED' where class_id=:c and status='CONFIRMED' and user_id = any(cast(:u as uuid[]))"),
                                 {"c": cls["id"], "u": [str(x) for x in b.user_ids]})
    return {"marked": res.rowcount}


# ============================================================ bookings & actions
@app.get("/api/bookings")
async def my_bookings(s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    rows = (await conn.execute(text(
        "select b.id as booking_id, b.status::text as status, c.id as class_id, c.title, c.start_time, c.end_time from class_bookings b "
        "join fitness_classes c on c.id=b.class_id where b.user_id=:u order by c.start_time desc limit 100"), {"u": s.user_id})).mappings().all()
    return {"bookings": [svc.jsonable(dict(r)) for r in rows]}


class ClassRef(Body):
    class_id: uuid.UUID


def _proposal(res: dict):
    if not res.get("ok"):
        status = {"CLASS_UNAVAILABLE": 404, "BOOKING_NOT_FOUND": 404, "TOO_MANY_PENDING_ACTIONS": 429}.get(res.get("error"), 409)
        raise HTTPException(status, res)
    return res


@app.post("/api/bookings/propose", status_code=201)
async def propose_booking(b: ClassRef, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    return _proposal(await svc.propose_book(conn, s, b.class_id))


@app.post("/api/classes/{class_id}/waitlist-propose", status_code=201)
async def waitlist_propose(class_id: uuid.UUID, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    return _proposal(await svc.propose_waitlist(conn, s, class_id))


@app.post("/api/bookings/{booking_id}/cancel-propose", status_code=201)
async def cancel_propose(booking_id: uuid.UUID, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    return _proposal(await svc.propose_cancel(conn, s, booking_id))


@app.get("/api/actions")
async def my_actions(s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    rows = (await conn.execute(text(
        "select id, type::text as type, summary, status::text as status, expires_at from pending_actions where user_id=:u and status='PENDING' and expires_at>now() order by created_at desc"),
        {"u": s.user_id})).mappings().all()
    return {"actions": [svc.jsonable(dict(r)) for r in rows]}


@app.post("/api/actions/{action_id}/confirm")
async def confirm(action_id: uuid.UUID, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    code, res = await svc.confirm_action(conn, s, action_id)
    if code != 200:
        raise HTTPException(code, res)
    if not res.get("ok"):
        return JSONResponse(status_code=409, content=res)
    return res


@app.post("/api/actions/{action_id}/reject")
async def reject(action_id: uuid.UUID, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    r = await conn.execute(text("update pending_actions set status='REJECTED' where id=:i and user_id=:u and status='PENDING'"), {"i": action_id, "u": s.user_id})
    if r.rowcount == 0:
        raise HTTPException(404, "No pending action")
    return {"ok": True}


# ============================================================ trainers
@app.get("/api/trainers")
async def trainers(specialization: str | None = None, s: SessionContext = Depends(get_session), conn=Depends(get_db)):
    return {"trainers": await T.trainers_list(conn, specialization[:40] if specialization else None)}


class ReviewBody(Body):
    rating: int = Field(ge=1, le=5)
    comment: str | None = Field(default=None, max_length=1000)


@app.post("/api/trainers/{trainer_id}/reviews", status_code=201)
async def review(trainer_id: uuid.UUID, b: ReviewBody, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    ok = (await conn.execute(text(
        "select 1 from class_bookings b join fitness_classes c on c.id=b.class_id where b.user_id=:u and c.trainer_id=:t and b.status='ATTENDED' limit 1"),
        {"u": s.user_id, "t": trainer_id})).scalar()
    if not ok:
        raise HTTPException(403, "You can only review trainers whose classes you attended")
    await conn.execute(text("insert into trainer_reviews (trainer_id, member_id, rating, comment) values (:t,:m,:r,:c) "
                            "on conflict (trainer_id, member_id) do update set rating=excluded.rating, comment=excluded.comment"),
                       {"t": trainer_id, "m": s.user_id, "r": b.rating, "c": b.comment})
    await conn.execute(text("update trainer_profiles set rating=(select round(avg(rating)::numeric,2) from trainer_reviews where trainer_id=:t), "
                            "review_count=(select count(*) from trainer_reviews where trainer_id=:t) where trainer_id=:t"), {"t": trainer_id})
    return {"ok": True}


# ============================================================ membership
@app.get("/api/plans")
async def plans(s: SessionContext = Depends(get_session), conn=Depends(get_db)):
    return await T.list_plans(None, T.RunContext(session=s, conn=conn, run_id=""))


@app.get("/api/me/membership")
async def my_membership(s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    return await T.get_my_membership(None, T.RunContext(session=s, conn=conn, run_id=""))


class PlanChangeBody(Body):
    plan_code: Literal["SILVER", "GOLD", "PLATINUM"]
    cycle: Literal["MONTHLY", "ANNUAL"] = "MONTHLY"


@app.post("/api/membership/propose-change", status_code=201)
async def propose_change(b: PlanChangeBody, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    return _proposal(await svc.propose_plan_change(conn, s, b.plan_code, b.cycle))


# ============================================================ health & nutrition
class LogBody(Body):
    log_date: date
    steps_walked: int = Field(default=0, ge=0, le=100000)
    active_calories_burned: int = Field(default=0, ge=0, le=10000)
    water_intake_ml: int = Field(default=0, ge=0, le=10000)
    hours_slept: float | None = Field(default=None, ge=0, le=24)


@app.post("/api/health/logs", status_code=201)
async def health_log(b: LogBody, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    if b.log_date > date.today() or b.log_date < date.today() - timedelta(days=365):
        raise HTTPException(422, "log_date out of range")
    await conn.execute(text(
        "insert into daily_health_logs (user_id, log_date, steps_walked, active_calories_burned, water_intake_ml, hours_slept) values (:u,:d,:s,:c,:w,:h) "
        "on conflict (user_id, log_date) do update set steps_walked=excluded.steps_walked, active_calories_burned=excluded.active_calories_burned, "
        "water_intake_ml=excluded.water_intake_ml, hours_slept=excluded.hours_slept"),
        {"u": s.user_id, "d": b.log_date, "s": b.steps_walked, "c": b.active_calories_burned, "w": b.water_intake_ml, "h": b.hours_slept})
    return {"ok": True}


@app.get("/api/health/summary")
async def health_summary(s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    if not s.health_consent:
        raise HTTPException(403, T.NEEDS_CONSENT)
    ctx = T.RunContext(session=s, conn=conn, run_id="")
    p = await T._profile(ctx)
    if not p:
        raise HTTPException(404, "Profile not found")
    e = calc.bmr(p["weight_kg"], p["height_cm"], p["age_years"], p["gender"])
    week = (await conn.execute(text(
        "select coalesce(sum(steps_walked),0) steps, coalesce(sum(active_calories_burned),0) kcal, coalesce(sum(water_intake_ml),0) water from daily_health_logs "
        "where user_id=:u and log_date > current_date - 7"), {"u": s.user_id})).mappings().one()
    return {"bmr": e, "tdee": calc.tdee(e, p["activity_level"]), **calc.bmi(p["weight_kg"], p["height_cm"]),
            "hydration_ml_rest_day": calc.hydration_ml(p["weight_kg"], 0), "last_7_days": dict(week),
            "disclaimer": "General wellness information, not medical advice."}


class NutritionBody(Body):
    goal: Literal["FAT_LOSS", "MUSCLE_GAIN", "MAINTENANCE", "ENDURANCE", "REHABILITATION"]
    dietary_preference: Literal["VEGAN", "VEGETARIAN", "NONE"] = "NONE"
    target_kcal: int | None = Field(default=None, ge=800, le=6000)
    split: Literal["FAT_LOSS", "MUSCLE_GAIN", "KETO", "BALANCED"] | None = None


@app.post("/api/nutrition/plan")
async def nutrition_plan(b: NutritionBody, s: SessionContext = Depends(require_roles("MEMBER")), conn=Depends(get_db)):
    if not s.health_consent:
        raise HTTPException(403, T.NEEDS_CONSENT)
    p = await T._profile(T.RunContext(session=s, conn=conn, run_id=""))
    if not p:
        raise HTTPException(404, "Profile not found")
    try:
        plan = nutrition.build_plan(p, b.goal, b.dietary_preference, b.target_kcal, b.split)
    except nutrition.Refusal as r:
        raise HTTPException(r.status, {"error": r.code, "detail": r.message, **r.extra})
    save = await svc.create_pending(conn, s, "SAVE_NUTRITION_PLAN", plan, f"Save your {b.goal.replace('_', ' ').lower()} plan ({plan['daily_calories']} kcal/day).")
    return {"plan": plan, "save_action": save if save["ok"] else None}


# ============================================================ notifications
@app.get("/api/notifications")
async def notifications(s: SessionContext = Depends(get_session), conn=Depends(get_db)):
    rows = (await conn.execute(text("select id, title, message, is_read, created_at from notifications where user_id=:u order by created_at desc limit 50"), {"u": s.user_id})).mappings().all()
    return {"notifications": [svc.jsonable(dict(r)) for r in rows]}


@app.post("/api/notifications/{nid}/read")
async def read_notification(nid: uuid.UUID, s: SessionContext = Depends(get_session), conn=Depends(get_db)):
    r = await conn.execute(text("update notifications set is_read=true where id=:i and user_id=:u"), {"i": nid, "u": s.user_id})
    if r.rowcount == 0:
        raise HTTPException(404, "Not found")
    return {"ok": True}


# ============================================================ admin
class NewUserBody(Body):
    email: EmailStr
    password: str = Field(min_length=10, max_length=72)
    full_name: str = Field(min_length=1, max_length=100)
    role: Literal["MEMBER", "TRAINER", "ADMIN"]
    specializations: list[str] = Field(default_factory=list, max_length=10)
    certifications: list[str] = Field(default_factory=list, max_length=10)


@app.post("/api/admin/users", status_code=201)
async def admin_create_user(b: NewUserBody, s: SessionContext = Depends(require_roles("ADMIN")), conn=Depends(get_db)):
    h = await hash_pw(b.password)
    try:
        async with conn.begin_nested():
            uid = (await conn.execute(text("insert into users (email, password_hash, full_name, role) values (:e,:h,:n,cast(:r as user_role)) returning id"),
                                      {"e": b.email, "h": h, "n": b.full_name, "r": b.role})).scalar()
    except IntegrityError:
        raise HTTPException(409, "Email already in use")
    if b.role == "TRAINER":
        await conn.execute(text("insert into trainer_profiles (trainer_id, specializations, certifications) values (:t,:s,:c)"),
                           {"t": uid, "s": b.specializations, "c": b.certifications})
    await conn.execute(text("insert into audit_log (actor_id, action, entity, entity_id) values (:a,'CREATE_USER','users',:e)"), {"a": s.user_id, "e": uid})
    return {"user_id": str(uid)}


class VerifyBody(Body):
    verified: bool = True


@app.post("/api/admin/trainers/{trainer_id}/verify")
async def verify_trainer(trainer_id: uuid.UUID, b: VerifyBody, s: SessionContext = Depends(require_roles("ADMIN")), conn=Depends(get_db)):
    r = await conn.execute(text("update trainer_profiles set certs_verified_at = case when :v then now() else null end where trainer_id=:t"), {"v": b.verified, "t": trainer_id})
    if r.rowcount == 0:
        raise HTTPException(404, "Trainer not found")
    return {"ok": True}


class GrantBody(Body):
    user_id: uuid.UUID
    plan_code: Literal["SILVER", "GOLD", "PLATINUM"]
    days: int = Field(default=30, ge=1, le=366)


@app.post("/api/admin/memberships", status_code=201)
async def admin_grant(b: GrantBody, s: SessionContext = Depends(require_roles("ADMIN")), conn=Depends(get_db)):
    price = (await conn.execute(text("select price_monthly from membership_plans where code=:c"), {"c": b.plan_code})).scalar()
    await conn.execute(text("update memberships set status='CANCELLED' where user_id=:u and status='ACTIVE'"), {"u": b.user_id})
    await conn.execute(text("insert into memberships (user_id, plan_code, price_paid, start_date, end_date) values (:u,:p,:pp,current_date,current_date + cast(:d as int))"),
                       {"u": b.user_id, "p": b.plan_code, "pp": price, "d": b.days})
    await conn.execute(text("insert into audit_log (actor_id, action, entity, entity_id) values (:a,'GRANT_MEMBERSHIP','users',:e)"), {"a": s.user_id, "e": b.user_id})
    return {"ok": True}


@app.get("/api/admin/analytics/{name}")
async def analytics(name: Literal["occupancy_rate", "mrr", "peak_hours"], days: int = 30, s: SessionContext = Depends(require_roles("ADMIN")), conn=Depends(get_db)):
    return await T.metric(conn, name, max(1, min(days, 180)))


@app.post("/api/admin/outbox/flush")
async def outbox_flush(s: SessionContext = Depends(require_roles("ADMIN")), conn=Depends(get_db)):
    async with as_system(conn, s.user_id, s.role):
        n = await svc.flush_outbox(conn)
    return {"delivered": n}


# ============================================================ agent chat
class ChatBody(Body):
    message: str = Field(min_length=1, max_length=2000)
    conversation_id: uuid.UUID


@app.post("/api/agent/chat", dependencies=[Depends(rate_limit("chat", 20, 60))])
async def chat(b: ChatBody, s: SessionContext = Depends(get_session), conn=Depends(get_db)):
    out = await agents.run_chat(conn, s, b.message, str(b.conversation_id))
    if out["status"] == "UNAVAILABLE":
        return JSONResponse(status_code=503, content=out)
    return out
