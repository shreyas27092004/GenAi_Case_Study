import time, uuid, collections, asyncio
from datetime import datetime, timedelta, timezone, date
import bcrypt, jwt
from anyio import to_thread
from fastapi import Depends, HTTPException, Header, Request
from pydantic import BaseModel
from sqlalchemy import text
from .db import engine, set_ctx
from .settings import settings

_DUMMY_HASH = bcrypt.hashpw(b"dummy-password-for-timing", bcrypt.gensalt())


class SessionContext(BaseModel):
    user_id: str
    role: str
    email: str
    full_name: str
    plan: str | None = None
    locale: str = "en"
    timezone: str = "UTC"
    age_years: int | None = None
    health_consent: bool = False
    is_minor: bool = False


async def hash_pw(pw: str) -> str:
    return (await to_thread.run_sync(lambda: bcrypt.hashpw(pw.encode(), bcrypt.gensalt()))).decode()


async def verify_pw(pw: str, hashed: str | None) -> bool:
    h = hashed.encode() if hashed else _DUMMY_HASH   # same work whether or not the user exists
    ok = await to_thread.run_sync(lambda: bcrypt.checkpw(pw.encode(), h))
    return ok and hashed is not None


def make_token(user_id: str) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": user_id, "iat": now, "exp": now + timedelta(minutes=settings.jwt_ttl_min), "aud": "gympro"},
                      settings.jwt_secret, algorithm=settings.jwt_alg)


def age_from(dob: date, today: date | None = None) -> int:
    t = today or date.today()
    return t.year - dob.year - ((t.month, t.day) < (dob.month, dob.day))


async def get_session(authorization: str | None = Header(default=None)) -> SessionContext:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing bearer token")
    try:
        claims = jwt.decode(authorization[7:].strip(), settings.jwt_secret, algorithms=[settings.jwt_alg],
                            audience="gympro", options={"require": ["exp", "sub", "aud"]})
        uid = str(uuid.UUID(claims["sub"]))
    except (jwt.PyJWTError, ValueError):
        raise HTTPException(401, "Invalid or expired token")
    async with engine.connect() as conn:
        async with conn.begin():
            await set_ctx(conn, uid, "SYSTEM")  # read own session data (RLS on member_profiles)
            u = (await conn.execute(text(
                "select id, email::text, full_name, role::text, locale, timezone from users "
                "where id=:u and is_active and deleted_at is null"), {"u": uid})).mappings().first()
            if not u:   # deactivated or deleted users lose access immediately, tokens notwithstanding
                raise HTTPException(401, "Account not available")
            plan = (await conn.execute(text(
                "select plan_code from memberships where user_id=:u and status='ACTIVE' and end_date>=current_date"),
                {"u": uid})).scalar()
            prof = (await conn.execute(text(
                "select date_of_birth, health_data_consent_at from member_profiles where user_id=:u"), {"u": uid})).mappings().first()
            gym_tz = (await conn.execute(text("select value #>> '{}' from gym_settings where key='timezone'"))).scalar() or "UTC"
    age = age_from(prof["date_of_birth"]) if prof else None
    return SessionContext(user_id=uid, role=u["role"], email=u["email"], full_name=u["full_name"], plan=plan,
                          locale=u["locale"], timezone=u["timezone"] or gym_tz, age_years=age,
                          health_consent=bool(prof and prof["health_data_consent_at"]),
                          is_minor=bool(age is not None and age < 18))


async def get_db(s: SessionContext = Depends(get_session)):
    async with engine.connect() as conn:
        async with conn.begin():
            await set_ctx(conn, s.user_id, s.role)
            yield conn


def require_roles(*roles: str):
    async def dep(s: SessionContext = Depends(get_session)) -> SessionContext:
        if s.role not in roles:
            raise HTTPException(403, "Forbidden")
        return s
    return dep


class RateLimiter:
    """In-process sliding window. Use Redis (or the gateway) when running more than one worker."""
    def __init__(self):
        self.hits: dict[str, collections.deque] = collections.defaultdict(collections.deque)

    def check(self, key: str, limit: int, window_s: int):
        now = time.monotonic()
        q = self.hits[key]
        while q and q[0] < now - window_s:
            q.popleft()
        if len(q) >= limit:
            raise HTTPException(429, "Too many requests", headers={"Retry-After": str(window_s)})
        q.append(now)


limiter = RateLimiter()


def rate_limit(name: str, limit: int, window_s: int = 60):
    """Per-USER limit (not per token: logging in again must not reset the counter)."""
    async def dep(s: SessionContext = Depends(get_session)):
        limiter.check(f"{name}:{s.user_id}", limit, window_s)
    return dep


def ip_rate_limit(name: str, limit: int, window_s: int = 60):
    async def dep(request: Request):
        limiter.check(f"{name}:{request.client.host if request.client else 'unknown'}", limit, window_s)
    return dep
