"""Deterministic nutrition planner with hard safety rules. (LLM may phrase/explain, never decide numbers.)"""
from . import calc

# name, kcal/serving, protein, carbs, fat, serving label, diet ('vegan'|'vegetarian'|'none'), allergens, slot role
FOODS = [
    ("Rolled oats", 150, 5, 27, 3, "40 g dry", "vegan", {"gluten"}, "carb"),
    ("Brown rice (cooked)", 215, 5, 45, 2, "1 cup", "vegan", set(), "carb"),
    ("Quinoa (cooked)", 220, 8, 39, 4, "1 cup", "vegan", set(), "carb"),
    ("Sweet potato", 115, 2, 27, 0, "1 medium", "vegan", set(), "carb"),
    ("Banana", 105, 1, 27, 0, "1 medium", "vegan", set(), "carb"),
    ("Whole-wheat roti", 120, 4, 22, 2, "1 piece", "vegan", {"gluten"}, "carb"),
    ("Lentils (cooked dal)", 230, 18, 40, 1, "1 cup", "vegan", set(), "protein"),
    ("Chickpeas (cooked)", 270, 15, 45, 4, "1 cup", "vegan", set(), "protein"),
    ("Tofu (firm)", 145, 16, 3, 9, "150 g", "vegan", {"soy"}, "protein"),
    ("Pea protein shake", 120, 24, 3, 2, "1 scoop", "vegan", set(), "protein"),
    ("Paneer", 265, 18, 4, 20, "100 g", "vegetarian", {"dairy"}, "protein"),
    ("Greek yogurt", 130, 17, 6, 4, "170 g", "vegetarian", {"dairy"}, "protein"),
    ("Eggs", 140, 12, 1, 10, "2 large", "vegetarian", {"egg"}, "protein"),
    ("Whey protein shake", 120, 24, 3, 1, "1 scoop", "vegetarian", {"dairy"}, "protein"),
    ("Chicken breast (grilled)", 165, 31, 0, 4, "100 g", "none", set(), "protein"),
    ("Fish fillet (baked)", 180, 26, 0, 8, "120 g", "none", {"fish"}, "protein"),
    ("Almonds", 165, 6, 6, 14, "28 g", "vegan", {"tree_nut"}, "fat"),
    ("Peanut butter", 190, 7, 7, 16, "2 tbsp", "vegan", {"peanut"}, "fat"),
    ("Avocado", 160, 2, 9, 15, "1/2 fruit", "vegan", set(), "fat"),
    ("Olive oil", 120, 0, 0, 14, "1 tbsp", "vegan", set(), "fat"),
    ("Broccoli (steamed)", 55, 4, 11, 1, "1 cup", "vegan", set(), "veg"),
    ("Spinach (sauteed)", 45, 5, 7, 1, "1 cup", "vegan", set(), "veg"),
]
DIET_RANK = {"vegan": 0, "vegetarian": 1, "none": 2}
ALLERGEN_ALIASES = {
    "dairy": "dairy", "milk": "dairy", "lactose": "dairy", "peanut": "peanut", "peanuts": "peanut",
    "tree nut": "tree_nut", "tree nuts": "tree_nut", "nuts": "tree_nut", "almond": "tree_nut", "almonds": "tree_nut",
    "soy": "soy", "soya": "soy", "gluten": "gluten", "wheat": "gluten", "egg": "egg", "eggs": "egg", "fish": "fish",
}
UNSUPPORTED = {"shellfish", "sesame", "mustard", "celery", "lupin", "sulphites", "sulfites", "mollusc"}
SLOTS = [("Breakfast", 0.25, ("carb", "protein", "veg")), ("Lunch", 0.35, ("carb", "protein", "veg")),
         ("Snack", 0.15, ("protein", "carb", "fat")), ("Dinner", 0.25, ("carb", "protein", "veg"))]


class Refusal(Exception):
    def __init__(self, status: int, code: str, message: str, **extra):
        self.status, self.code, self.message, self.extra = status, code, message, extra


def normalize_allergies(allergies: list[str]) -> set[str]:
    out = set()
    for a in allergies:
        k = a.strip().lower()
        if k in ALLERGEN_ALIASES:
            out.add(ALLERGEN_ALIASES[k])
        else:   # fail closed: we cannot guarantee exclusion of an allergen we don't model
            raise Refusal(422, "UNSUPPORTED_ALLERGEN", f"I can't safely plan around '{a}'. Please see a registered dietitian.",
                          supported=sorted(set(ALLERGEN_ALIASES.values())))
    return out


def build_plan(profile: dict, goal: str, diet: str, target_kcal: int | None, split_name: str | None) -> dict:
    age, sex = profile["age_years"], profile["gender"]
    if age < 18:
        raise Refusal(403, "MINOR_NOT_SUPPORTED", "Calorie-targeted plans aren't available under 18. A registered dietitian or doctor can help.", referral="dietitian")
    if profile.get("is_pregnant"):
        raise Refusal(403, "PREGNANCY_NOT_SUPPORTED", "Please get nutrition guidance from your doctor or dietitian during pregnancy.", referral="physician")
    if sex == "FEMALE" and 18 <= age <= 50 and profile.get("is_pregnant") is None:
        raise Refusal(422, "MISSING_FIELD", "Please answer the pregnancy question in your profile first.", missing_fields=["is_pregnant"])
    excluded = normalize_allergies(profile.get("allergies") or [])
    bmr = calc.bmr(profile["weight_kg"], profile["height_cm"], age, sex)
    tdee = calc.tdee(bmr, profile["activity_level"])
    delta = {"FAT_LOSS": -400, "MUSCLE_GAIN": 300}.get(goal, 0)
    floor = calc.calorie_floor(sex)
    if target_kcal is None:
        target_kcal = max(floor, round(tdee + delta))
    if target_kcal < floor or target_kcal < tdee - 500 or not (0.7 * tdee <= target_kcal <= 1.3 * tdee):
        raise Refusal(422, "UNSAFE_CALORIE_TARGET",
                      f"That target is outside safe limits for you (minimum {floor} kcal, at most 500 kcal below maintenance, within 30% of {round(tdee)}).",
                      safe_range=[max(floor, round(tdee - 500), round(0.7 * tdee)), round(1.3 * tdee)])
    split = split_name or {"FAT_LOSS": "FAT_LOSS", "MUSCLE_GAIN": "MUSCLE_GAIN"}.get(goal, "BALANCED")
    if split == "KETO" and (profile.get("medical_flag")):
        raise Refusal(403, "KETO_NOT_SUPPORTED", "Please consult a clinician before a very-low-carb plan.")
    target_macros = calc.macros(target_kcal, split)
    allowed = [f for f in FOODS if DIET_RANK[f[6]] <= DIET_RANK[{"VEGAN": "vegan", "VEGETARIAN": "vegetarian"}.get(diet.upper(), "none")]
               and not (f[7] & excluded)]
    meals = []
    for name, share, roles in SLOTS:
        slot_kcal = target_kcal * share
        picks = []
        for r in roles:
            pool = [f for f in allowed if f[8] == r]
            if pool:
                picks.append(pool[(len(meals) + len(picks)) % len(pool)])
        base = sum(p[1] for p in picks)
        if not picks or base == 0:
            raise Refusal(422, "NO_SAFE_FOODS", "No foods match your restrictions; please see a dietitian.")
        scale = slot_kcal / base
        items = []
        for p in picks:
            servings = max(0.25, round(scale * 4) / 4)       # servings in quarter steps
            items.append({"food": p[0], "qty": f"{servings:g} x {p[5]}", "kcal": round(p[1] * servings),
                          "protein_g": round(p[2] * servings), "carbs_g": round(p[3] * servings), "fat_g": round(p[4] * servings)})
        meals.append({"meal": name, "items": items, "kcal": sum(i["kcal"] for i in items), "protein_g": sum(i["protein_g"] for i in items)})
    total_kcal = sum(m["kcal"] for m in meals)
    acts = {"protein_g": sum(i["protein_g"] for m in meals for i in m["items"]), "carbs_g": sum(i["carbs_g"] for m in meals for i in m["items"]),
            "fats_g": sum(i["fat_g"] for m in meals for i in m["items"])}
    # Reported numbers are what the meals actually deliver; plan must be within 5% of the safe target or it is refused.
    if abs(total_kcal - target_kcal) > 0.05 * target_kcal:
        raise Refusal(422, "PLAN_ACCURACY", "Couldn't build an accurate plan for those constraints; please adjust diet options.")
    for m in meals:   # allergen re-check on the final output (defense in depth)
        for i in m["items"]:
            f = next(x for x in FOODS if x[0] == i["food"])
            assert not (f[7] & excluded)
    return {"goal": goal, "dietary_preference": diet.upper(), "daily_calories": total_kcal, "target_calories": target_kcal,
            "macros": acts, "target_macros": target_macros, "split_used": split, "tdee_basis": round(tdee),
            "meals": meals, "allergen_check": {"allergies": sorted(excluded), "violations": []},
            "notes": ["General wellness information, not medical advice."] + (["Very-low-carb diets aren't suitable for everyone."] if split == "KETO" else []),
            "referral": "none"}
