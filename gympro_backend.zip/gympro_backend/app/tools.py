"""Tool layer. Authorization, identity injection and safety constraints are enforced HERE, never by the prompt."""
import json
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Literal, Type
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from sqlalchemy import text
from . import calc, nutrition, services as svc
from .auth import SessionContext, age_from
from .db import gym_setting


class Args(BaseModel):
    model_config = ConfigDict(extra="forbid")      # a model can't smuggle user_id/role/etc. into any tool


@dataclass
class RunContext:
    session: SessionContext
    conn: Any
    run_id: str
    constraints: dict = field(default_factory=lambda: {"codes": [], "max_impact": "HIGH", "avoid_categories": []})
    proposed: set = field(default_factory=set)       # action_ids created in THIS run (anti-fabrication)
    tool_log: list = field(default_factory=list)
    tokens_in: int = 0
    tokens_out: int = 0
    last_plan: dict | None = None
    budget: int = 20000

    def meter(self, usage):
        if usage is not None:
            self.tokens_in += getattr(usage, "prompt_tokens", 0) or 0
            self.tokens_out += getattr(usage, "completion_tokens", 0) or 0
        if self.tokens_in + self.tokens_out > self.budget:
            raise BudgetExceeded()


class BudgetExceeded(Exception):
    pass


@dataclass(frozen=True)
class Tool:
    name: str
    args: Type[BaseModel]
    fn: Callable[[Any, RunContext], Awaitable[dict]]
    roles: frozenset
    agents: frozenset
    kind: str            # read | propose | calc
    description: str


TOOLS: dict[str, Tool] = {}


def tool(name, args, agents, roles=("MEMBER", "TRAINER", "ADMIN"), kind="read", desc=""):
    def deco(fn):
        TOOLS[name] = Tool(name, args, fn, frozenset(roles), frozenset(agents), kind, desc or (fn.__doc__ or name))
        return fn
    return deco


def tool_specs(agent: str, role: str):
    return [{"type": "function", "function": {"name": t.name, "description": t.description,
             "parameters": t.args.model_json_schema()}} for t in TOOLS.values() if agent in t.agents and role in t.roles]


async def dispatch(name: str, raw: Any, ctx: RunContext, agent: str) -> dict:
    t = TOOLS.get(name)
    if t is None or agent not in t.agents:
        return {"ok": False, "error": "TOOL_NOT_ALLOWED"}
    if ctx.session.role not in t.roles:
        return {"ok": False, "error": "FORBIDDEN"}
    try:
        args = t.args.model_validate(raw if isinstance(raw, dict) else {})
    except ValidationError as e:
        return {"ok": False, "error": "INVALID_ARGUMENTS", "detail": str(e.errors()[0]["msg"])[:160]}
    try:
        async with ctx.conn.begin_nested():          # a failing tool can't poison the request transaction
            res = await t.fn(args, ctx)
    except Exception as e:                            # noqa: BLE001 - never leak internals to the model
        res = {"ok": False, "error": "TOOL_ERROR"}
        ctx.tool_log.append({"agent": agent, "tool": name, "ok": False, "error_code": type(e).__name__})
        return res
    ctx.tool_log.append({"agent": agent, "tool": name, "ok": bool(res.get("ok", True)), "error_code": res.get("error")})
    if t.kind == "propose" and res.get("ok") and res.get("action_id"):
        ctx.proposed.add(res["action_id"])
    return res


async def _profile(ctx: RunContext) -> dict | None:
    s = ctx.session
    if not s.health_consent:
        return None
    r = (await ctx.conn.execute(text(
        "select date_of_birth, gender::text as gender, height_cm, weight_kg, activity_level, known_injuries, allergies, "
        "dietary_preference, is_pregnant, goal::text as goal from member_profiles where user_id=:u"), {"u": s.user_id})).mappings().first()
    if not r:
        return None
    d = dict(r)
    d["age_years"] = age_from(d.pop("date_of_birth"))
    d["height_cm"], d["weight_kg"] = float(d["height_cm"]), float(d["weight_kg"])
    return d


NEEDS_CONSENT = {"ok": False, "error": "CONSENT_REQUIRED", "detail": "Enable health-data personalization in settings first."}

# ---------------------------------------------------------------- SCHEDULE
class SearchClassesArgs(Args):
    category: Literal["HIIT", "YOGA", "PILATES", "SPIN", "STRENGTH", "ZUMBA", "SWIMMING", "RECOVERY"] | None = None
    date_from: str | None = None
    date_to: str | None = None
    max_impact: Literal["LOW", "MODERATE", "HIGH"] | None = None
    trainer_id: str | None = None


def _dt(v):
    from datetime import datetime
    if not v:
        return None
    d = datetime.fromisoformat(v)
    if d.tzinfo is None:
        from zoneinfo import ZoneInfo
        raise ValueError("timezone offset required")
    return d


@tool("search_classes", SearchClassesArgs, ["SCHEDULE"], desc="Search upcoming classes. Safety filters are applied automatically.")
async def search_classes(a: SearchClassesArgs, ctx: RunContext):
    c = ctx.constraints
    mi = min([x for x in [a.max_impact, c["max_impact"]] if x], key=lambda k: svc.IMPACT_RANK[k])  # stricter of the two, always
    try:
        f, t = _dt(a.date_from), _dt(a.date_to)
    except ValueError:
        return {"ok": False, "error": "INVALID_ARGUMENTS", "detail": "date_from/date_to must be ISO-8601 with offset"}
    rows = await svc.list_classes(ctx.conn, date_from=f, date_to=t, category=a.category, max_impact=mi, exclude_codes=c["codes"],
                                  exclude_categories=c["avoid_categories"], trainer_id=a.trainer_id, limit=10)
    return {"ok": True, "classes": rows, "filtered_for_safety": bool(c["codes"] or c["avoid_categories"])}


class NoArgs(Args):
    pass


class BookingRange(Args):
    days: int = Field(default=14, ge=1, le=60)


@tool("get_my_bookings", BookingRange, ["SCHEDULE"], roles=("MEMBER",))
async def get_my_bookings(a: BookingRange, ctx: RunContext):
    rows = (await ctx.conn.execute(text(
        "select b.id as booking_id, b.status::text as status, c.id as class_id, c.title, c.start_time, c.end_time from class_bookings b "
        "join fitness_classes c on c.id=b.class_id where b.user_id=:u and b.status in ('CONFIRMED','WAITLISTED') "
        "and c.start_time >= now() and c.start_time < now() + make_interval(days => :d) order by c.start_time"),
        {"u": ctx.session.user_id, "d": a.days})).mappings().all()
    return {"ok": True, "bookings": [svc.jsonable(dict(r)) for r in rows]}


class ClassIdArgs(Args):
    class_id: str


@tool("check_conflicts", ClassIdArgs, ["SCHEDULE"], roles=("MEMBER",))
async def check_conflicts(a: ClassIdArgs, ctx: RunContext):
    cls = await svc.get_class(ctx.conn, a.class_id)
    if not cls:
        return {"ok": False, "error": "CLASS_UNAVAILABLE"}
    cf = await svc.find_conflicts(ctx.conn, ctx.session.user_id, cls)
    return {"ok": True, "conflicts": cf, "no_conflict": not cf}


@tool("get_membership_entitlements", NoArgs, ["SCHEDULE", "MEMBERSHIP"], roles=("MEMBER",))
async def get_entitlements(a, ctx: RunContext):
    return {"ok": True, **await svc.entitlements(ctx.conn, ctx.session.user_id, svc.now_utc())}


@tool("propose_booking", ClassIdArgs, ["SCHEDULE"], roles=("MEMBER",), kind="propose", desc="Create a booking PROPOSAL; the member must confirm in the UI.")
async def propose_booking(a: ClassIdArgs, ctx: RunContext):
    return await svc.propose_book(ctx.conn, ctx.session, a.class_id, enforce=ctx.constraints, run_id=ctx.run_id)


@tool("propose_waitlist", ClassIdArgs, ["SCHEDULE"], roles=("MEMBER",), kind="propose")
async def propose_waitlist(a: ClassIdArgs, ctx: RunContext):
    return await svc.propose_waitlist(ctx.conn, ctx.session, a.class_id, run_id=ctx.run_id)


class BookingIdArgs(Args):
    booking_id: str


@tool("propose_cancellation", BookingIdArgs, ["SCHEDULE"], roles=("MEMBER",), kind="propose")
async def propose_cancellation(a: BookingIdArgs, ctx: RunContext):
    return await svc.propose_cancel(ctx.conn, ctx.session, a.booking_id, run_id=ctx.run_id)


# ---------------------------------------------------------------- TRAINER
class SearchTrainersArgs(Args):
    specialization: str | None = Field(default=None, max_length=40)
    min_reviews: int = Field(default=0, ge=0, le=100)


@tool("search_trainers", SearchTrainersArgs, ["TRAINER"], desc="List trainers. Credentials are shown only when verified; ratings only with >= 5 reviews.")
async def search_trainers(a: SearchTrainersArgs, ctx: RunContext):
    return {"ok": True, "trainers": await trainers_list(ctx.conn, a.specialization, a.min_reviews)}


async def trainers_list(conn, specialization=None, min_reviews=0):
    rows = (await conn.execute(text(
        "select t.trainer_id, u.full_name, t.specializations, t.certifications, t.certs_verified_at, t.rating, t.review_count, t.hourly_rate, t.bio "
        "from trainer_profiles t join users u on u.id=t.trainer_id where t.accepting_clients and u.is_active and u.deleted_at is null "
        "and t.review_count >= :mr and (cast(:sp as text) is null or exists (select 1 from unnest(t.specializations) s where lower(s) like '%'||lower(cast(:sp as text))||'%')) "
        "order by (coalesce(t.rating,0) * t.review_count + 4.0 * 5) / (t.review_count + 5) desc limit 10"),
        {"sp": specialization, "mr": min_reviews})).mappings().all()
    out = []
    for r in rows:
        verified = r["certs_verified_at"] is not None
        out.append({"trainer_id": str(r["trainer_id"]), "name": r["full_name"], "specializations": r["specializations"],
                    "verified_certifications": r["certifications"] if verified else [],
                    "rating": float(r["rating"]) if r["rating"] is not None and r["review_count"] >= 5 else None,
                    "review_count": r["review_count"], "is_new": r["review_count"] < 5, "hourly_rate": float(r["hourly_rate"])})
    return out


# ---------------------------------------------------------------- HEALTH
@tool("get_my_health_profile", NoArgs, ["HEALTH", "FITNESS", "NUTRITION"], roles=("MEMBER",))
async def get_my_health_profile(a, ctx: RunContext):
    p = await _profile(ctx)
    if p is None:
        return NEEDS_CONSENT if not ctx.session.health_consent else {"ok": False, "error": "PROFILE_MISSING"}
    return {"ok": True, "age_years": p["age_years"], "goal": p["goal"], "known_injuries": p["known_injuries"], "activity_level": p["activity_level"]}


@tool("calc_energy", NoArgs, ["HEALTH", "NUTRITION"], roles=("MEMBER",), kind="calc", desc="BMR/TDEE (Mifflin-St Jeor) from the member's stored profile.")
async def calc_energy(a, ctx: RunContext):
    p = await _profile(ctx)
    if p is None:
        return NEEDS_CONSENT
    b = calc.bmr(p["weight_kg"], p["height_cm"], p["age_years"], p["gender"])
    return {"ok": True, "bmr": b, "tdee": calc.tdee(b, p["activity_level"]), "formula": "Mifflin-St Jeor"}


@tool("calc_bmi", NoArgs, ["HEALTH"], roles=("MEMBER",), kind="calc")
async def calc_bmi(a, ctx: RunContext):
    p = await _profile(ctx)
    return {"ok": True, **calc.bmi(p["weight_kg"], p["height_cm"])} if p else NEEDS_CONSENT


class HydrationArgs(Args):
    class_minutes: int = Field(default=0, ge=0, le=300)


@tool("calc_hydration", HydrationArgs, ["HEALTH"], roles=("MEMBER",), kind="calc")
async def calc_hydration(a: HydrationArgs, ctx: RunContext):
    p = await _profile(ctx)
    return {"ok": True, "ml": calc.hydration_ml(p["weight_kg"], a.class_minutes),
            "note": "People with kidney, heart or fluid-restriction conditions should follow their clinician's advice."} if p else NEEDS_CONSENT


class InjuryArgs(Args):
    codes: list[Literal["KNEE", "LOWER_BACK", "SHOULDER", "ANKLE", "WRIST", "NECK"]] = Field(max_length=6)


@tool("get_injury_protocol", InjuryArgs, ["HEALTH"], kind="calc")
async def get_injury_protocol(a: InjuryArgs, ctx: RunContext):
    c = svc.constraints_from_codes(a.codes)
    # Constraints from the HEALTH agent bind every later agent in this run (server-side, not via LLM handoff text).
    ctx.constraints = {"codes": sorted(set(ctx.constraints["codes"]) | set(c["codes"])),
                       "max_impact": min([ctx.constraints["max_impact"], c["max_impact"]], key=lambda k: svc.IMPACT_RANK[k]),
                       "avoid_categories": sorted(set(ctx.constraints["avoid_categories"]) | set(c["avoid_categories"]))}
    return {"ok": True, **c, "preferred": sorted({p for x in a.codes for p in svc.INJURY_PROTOCOLS[x]["preferred"]})}


# ---------------------------------------------------------------- FITNESS
class ProgressionArgs(Args):
    current_sessions_per_week: int = Field(ge=0, le=14)
    level: Literal["BEGINNER", "INTERMEDIATE", "ADVANCED"]


@tool("calc_progression", ProgressionArgs, ["FITNESS"], kind="calc")
async def calc_progression(a: ProgressionArgs, ctx: RunContext):
    cap = {"BEGINNER": 3, "INTERMEDIATE": 4, "ADVANCED": 5}[a.level]
    w1 = min(a.current_sessions_per_week + 1, cap) if a.current_sessions_per_week else 2
    plan = [min(cap, w1 + (1 if i >= 2 and w1 < cap else 0)) for i in range(4)]
    return {"ok": True, "weekly_sessions": plan, "cap": cap, "rest_days_min": 2}


@tool("get_class_catalog_summary", NoArgs, ["FITNESS"])
async def class_catalog(a, ctx: RunContext):
    rows = (await ctx.conn.execute(text(
        "select category::text as category, max(impact)::text as max_impact, count(*) as upcoming from fitness_classes "
        "where status='SCHEDULED' and start_time>now() group by category"))).mappings().all()
    return {"ok": True, "categories": [dict(r) for r in rows]}


# ---------------------------------------------------------------- MEMBERSHIP
@tool("list_plans", NoArgs, ["MEMBERSHIP"])
async def list_plans(a, ctx: RunContext):
    rows = (await ctx.conn.execute(text("select code, display_name, price_monthly, price_annual, currency, perks::text as perks from membership_plans where is_active order by sort_order"))).mappings().all()
    return {"ok": True, "plans": [{**svc.jsonable(dict(r)), "perks": json.loads(r["perks"]), "price_monthly": float(r["price_monthly"]),
                                   "price_annual": float(r["price_annual"]) if r["price_annual"] is not None else None} for r in rows]}


@tool("get_my_membership", NoArgs, ["MEMBERSHIP"], roles=("MEMBER",))
async def get_my_membership(a, ctx: RunContext):
    r = (await ctx.conn.execute(text(
        "select plan_code, status::text as status, billing_cycle::text as cycle, end_date, auto_renew from memberships where user_id=:u and status='ACTIVE' and end_date>=current_date"),
        {"u": ctx.session.user_id})).mappings().first()
    return {"ok": True, "membership": svc.jsonable(dict(r)) if r else None, **await svc.entitlements(ctx.conn, ctx.session.user_id, svc.now_utc())}


class PlanArgs(Args):
    to_plan: Literal["SILVER", "GOLD", "PLATINUM"]
    cycle: Literal["MONTHLY", "ANNUAL"] = "MONTHLY"


@tool("price_diff", PlanArgs, ["MEMBERSHIP"], roles=("MEMBER",), kind="calc")
async def price_diff(a: PlanArgs, ctx: RunContext):
    return svc.jsonable(await svc.plan_pricing(ctx.conn, ctx.session, a.to_plan, a.cycle))


@tool("propose_plan_change", PlanArgs, ["MEMBERSHIP"], roles=("MEMBER",), kind="propose")
async def propose_plan_change(a: PlanArgs, ctx: RunContext):
    return await svc.propose_plan_change(ctx.conn, ctx.session, a.to_plan, a.cycle, run_id=ctx.run_id)


# ---------------------------------------------------------------- NUTRITION
class BuildPlanArgs(Args):
    goal: Literal["FAT_LOSS", "MUSCLE_GAIN", "MAINTENANCE", "ENDURANCE", "REHABILITATION"]
    dietary_preference: Literal["VEGAN", "VEGETARIAN", "NONE"] = "NONE"
    target_kcal: int | None = Field(default=None, ge=800, le=6000)
    split: Literal["FAT_LOSS", "MUSCLE_GAIN", "KETO", "BALANCED"] | None = None


@tool("build_nutrition_plan", BuildPlanArgs, ["NUTRITION"], roles=("MEMBER",), kind="calc", desc="Deterministic, safety-checked plan generator.")
async def build_nutrition_plan(a: BuildPlanArgs, ctx: RunContext):
    p = await _profile(ctx)
    if p is None:
        return NEEDS_CONSENT
    try:
        plan = nutrition.build_plan(p, a.goal, a.dietary_preference, a.target_kcal, a.split)
    except nutrition.Refusal as r:
        return {"ok": False, "error": r.code, "detail": r.message, **r.extra}
    ctx.last_plan = plan
    return {"ok": True, "plan": plan}


@tool("propose_save_plan", NoArgs, ["NUTRITION"], roles=("MEMBER",), kind="propose", desc="Propose saving the plan produced by build_nutrition_plan in this run.")
async def propose_save_plan(a, ctx: RunContext):
    if not ctx.last_plan:
        return {"ok": False, "error": "NO_PLAN_IN_RUN"}
    p = ctx.last_plan
    return await svc.create_pending(ctx.conn, ctx.session, "SAVE_NUTRITION_PLAN", p, f"Save your {p['goal'].replace('_',' ').lower()} plan ({p['daily_calories']} kcal/day).", ctx.run_id)


# ---------------------------------------------------------------- ANALYTICS (ADMIN)
class MetricArgs(Args):
    name: Literal["occupancy_rate", "mrr", "peak_hours"]
    days: int = Field(default=30, ge=1, le=180)


@tool("get_metric", MetricArgs, ["ANALYTICS"], roles=("ADMIN",), kind="read")
async def get_metric(a: MetricArgs, ctx: RunContext):
    return await metric(ctx.conn, a.name, a.days)


async def metric(conn, name: str, days: int) -> dict:
    tz = await gym_setting(conn, "timezone", "UTC")
    if name == "occupancy_rate":
        r = (await conn.execute(text(
            "select coalesce(sum(booked_count),0) as booked, coalesce(sum(capacity),0) as cap, count(*) as classes from fitness_classes "
            "where status<>'CANCELLED' and end_time < now() and start_time >= now() - make_interval(days => :d)"), {"d": days})).mappings().one()
        by = (await conn.execute(text(
            "select category::text as label, round(sum(booked_count)::numeric / nullif(sum(capacity),0), 4) as value from fitness_classes "
            "where status<>'CANCELLED' and end_time < now() and start_time >= now() - make_interval(days => :d) group by category order by value desc"), {"d": days})).mappings().all()
        return {"ok": True, "metric": "occupancy_rate", "window_days": days, "timezone": tz, "classes": r["classes"],
                "overall": {"value": round(r["booked"] / r["cap"], 4) if r["cap"] else None, "unit": "ratio"},
                "by_category": [{"label": x["label"], "value": float(x["value"]) if x["value"] is not None else None} for x in by]}
    if name == "mrr":
        v = (await conn.execute(text(
            "select coalesce(sum(case when billing_cycle='ANNUAL' then price_paid/12 else price_paid end),0) from memberships where status='ACTIVE' and end_date>=current_date"))).scalar()
        return {"ok": True, "metric": "mrr", "value": round(float(v), 2), "unit": "currency_per_month"}
    rows = (await conn.execute(text(
        "select extract(hour from c.start_time at time zone :tz)::int as hour, count(*) as bookings from class_bookings b join fitness_classes c on c.id=b.class_id "
        "where b.status in ('CONFIRMED','ATTENDED') and c.start_time >= now() - make_interval(days => :d) group by 1 order by bookings desc limit 5"),
        {"tz": tz, "d": days})).mappings().all()
    return {"ok": True, "metric": "peak_hours", "timezone": tz, "window_days": days, "hours": [{"hour": r["hour"], "bookings": r["bookings"]} for r in rows]}
