"""Business logic shared by REST endpoints AND agent tools. All state changes happen here, inside transactions."""
import json, uuid
from decimal import Decimal
from datetime import datetime, timedelta, timezone, date
from zoneinfo import ZoneInfo
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from .auth import SessionContext
from .db import as_system, gym_setting
from .settings import settings

IMPACT_RANK = {"LOW": 0, "MODERATE": 1, "HIGH": 2}
MAX_PENDING_PER_USER = 5

INJURY_PROTOCOLS = {  # fallback protocol table; replace with the reviewed KB (physio sign-off) in production
    "KNEE": {"avoid_categories": ["HIIT"], "max_impact": "LOW", "preferred": ["SWIMMING", "YOGA", "PILATES"]},
    "LOWER_BACK": {"avoid_categories": [], "max_impact": "MODERATE", "preferred": ["PILATES", "YOGA", "RECOVERY"]},
    "SHOULDER": {"avoid_categories": [], "max_impact": "MODERATE", "preferred": ["SWIMMING", "YOGA", "SPIN"]},
    "ANKLE": {"avoid_categories": ["HIIT", "ZUMBA"], "max_impact": "LOW", "preferred": ["SWIMMING", "YOGA"]},
    "WRIST": {"avoid_categories": [], "max_impact": "MODERATE", "preferred": ["SPIN", "ZUMBA"]},
    "NECK": {"avoid_categories": [], "max_impact": "LOW", "preferred": ["YOGA", "RECOVERY", "PILATES"]},
}


def iso(v):
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, uuid.UUID):
        return str(v)
    if isinstance(v, Decimal):
        return float(v)
    return str(v)          # never return v itself: json's default hook would recurse forever


def jsonable(o):
    return json.loads(json.dumps(o, default=iso))


def now_utc():
    return datetime.now(timezone.utc)


def fmt_local(dt: datetime, tz: str) -> str:
    return dt.astimezone(ZoneInfo(tz)).strftime("%a %d %b, %I:%M %p")


def constraints_from_codes(codes) -> dict:
    codes = {c for c in codes if c in INJURY_PROTOCOLS}
    mx = min((IMPACT_RANK[INJURY_PROTOCOLS[c]["max_impact"]] for c in codes), default=2)
    return {"codes": sorted(codes), "max_impact": [k for k, v in IMPACT_RANK.items() if v == mx][0],
            "avoid_categories": sorted({a for c in codes for a in INJURY_PROTOCOLS[c]["avoid_categories"]})}


async def member_injury_codes(conn, s: SessionContext) -> list[str]:
    if not s.health_consent:
        return []
    r = (await conn.execute(text("select known_injuries from member_profiles where user_id=:u"), {"u": s.user_id})).scalar()
    return [x for x in (r or []) if x in INJURY_PROTOCOLS]


# ------------------------------------------------------------------ classes
CLASS_COLS = """c.id, c.title, c.category::text as category, c.impact::text as impact, c.contraindicated_for,
  c.min_level::text as min_level, c.est_calories_burned, c.capacity, c.booked_count, c.start_time, c.end_time,
  c.status::text as status, c.trainer_id, u.full_name as trainer_name"""


def class_view(r) -> dict:
    d = dict(r)
    d["spots_left"] = max(0, d["capacity"] - d["booked_count"])
    return jsonable(d)


async def list_classes(conn, *, date_from=None, date_to=None, category=None, max_impact=None,
                       exclude_codes=None, exclude_categories=None, trainer_id=None, limit=25):
    now = now_utc()
    date_from = max(date_from or now, now)               # never list the past
    date_to = min(date_to or date_from + timedelta(days=14), date_from + timedelta(days=31))
    where = ["c.status='SCHEDULED'", "c.start_time >= :f", "c.start_time < :t"]
    p = {"f": date_from, "t": date_to, "lim": max(1, min(limit, 50))}
    if category:
        where.append("c.category = cast(:cat as class_category)"); p["cat"] = category
    if max_impact:
        where.append("c.impact <= cast(:mi as impact_level)"); p["mi"] = max_impact
    if exclude_codes:
        where.append("not (c.contraindicated_for && cast(:ex as text[]))"); p["ex"] = list(exclude_codes)
    if exclude_categories:
        where.append("not (c.category::text = any(cast(:exc as text[])))"); p["exc"] = list(exclude_categories)
    if trainer_id:
        where.append("c.trainer_id = cast(:tr as uuid)"); p["tr"] = str(trainer_id)
    rows = (await conn.execute(text(
        f"select {CLASS_COLS} from fitness_classes c join users u on u.id=c.trainer_id "
        f"where {' and '.join(where)} order by c.start_time limit :lim"), p)).mappings().all()
    return [class_view(r) for r in rows]


async def get_class(conn, class_id, lock=False):
    q = f"select {CLASS_COLS} from fitness_classes c join users u on u.id=c.trainer_id where c.id=cast(:i as uuid)"
    if lock:
        q = f"select c.* from fitness_classes c where c.id=cast(:i as uuid) for update"
    return (await conn.execute(text(q), {"i": str(class_id)})).mappings().first()


# ------------------------------------------------------------------ entitlements & conflicts
async def entitlements(conn, user_id: str, at: datetime) -> dict:
    m = (await conn.execute(text(
        "select m.plan_code, p.perks::text as perks from memberships m join membership_plans p on p.code=m.plan_code "
        "where m.user_id=:u and m.status='ACTIVE' and m.end_date >= current_date"), {"u": user_id})).mappings().first()
    if not m:
        return {"can_book": False, "reason": "NO_ACTIVE_MEMBERSHIP", "remaining": None, "plan": None}
    limit = json.loads(m["perks"]).get("group_classes_per_month")
    if limit is None:
        return {"can_book": True, "reason": None, "remaining": None, "plan": m["plan_code"]}
    tz = await gym_setting(conn, "timezone", "UTC")
    used = (await conn.execute(text(
        "select count(*) from class_bookings b join fitness_classes c on c.id=b.class_id "
        "where b.user_id=:u and b.status in ('CONFIRMED','ATTENDED') and c.status<>'CANCELLED' "
        "and date_trunc('month', c.start_time at time zone :tz) = date_trunc('month', cast(:at as timestamptz) at time zone :tz)"),
        {"u": user_id, "tz": tz, "at": at})).scalar()
    rem = max(0, limit - used)
    return {"can_book": rem > 0, "reason": None if rem > 0 else "MONTHLY_CLASS_LIMIT_REACHED", "remaining": rem, "plan": m["plan_code"]}


async def find_conflicts(conn, user_id: str, cls) -> list[dict]:
    buf = int(await gym_setting(conn, "booking_buffer_minutes", 15))
    rows = (await conn.execute(text(
        "select b.id as booking_id, c.id as class_id, c.title from class_bookings b join fitness_classes c on c.id=b.class_id "
        "where b.user_id=:u and b.status='CONFIRMED' and c.status<>'CANCELLED' and c.id <> :cid "
        "and tstzrange(c.start_time - make_interval(mins => :buf), c.end_time + make_interval(mins => :buf)) "
        "&& tstzrange(:s, :e)"), {"u": user_id, "cid": cls["id"], "buf": buf, "s": cls["start_time"], "e": cls["end_time"]})).mappings().all()
    return [jsonable(dict(r)) | {"reason": "OVERLAP_OR_INSUFFICIENT_BUFFER"} for r in rows]


# ------------------------------------------------------------------ pending actions (LLM/UI -> confirm boundary)
async def create_pending(conn, s: SessionContext, atype: str, payload: dict, summary: str, run_id=None) -> dict:
    ttl = int(await gym_setting(conn, "pending_action_ttl_min", 10))
    existing = (await conn.execute(text(
        "select id, summary, expires_at from pending_actions where user_id=:u and type=cast(:t as action_type) "
        "and status='PENDING' and expires_at>now() and payload = cast(:p as jsonb)"),
        {"u": s.user_id, "t": atype, "p": json.dumps(payload)})).mappings().first()
    if existing:  # idempotent proposal
        return {"ok": True, "action_id": str(existing["id"]), "summary": existing["summary"], "expires_at": existing["expires_at"].isoformat()}
    n = (await conn.execute(text("select count(*) from pending_actions where user_id=:u and status='PENDING' and expires_at>now()"),
                            {"u": s.user_id})).scalar()
    if n >= MAX_PENDING_PER_USER:
        return {"ok": False, "error": "TOO_MANY_PENDING_ACTIONS"}
    row = (await conn.execute(text(
        "insert into pending_actions (user_id, run_id, type, payload, summary, expires_at) "
        "values (:u, :r, cast(:t as action_type), cast(:p as jsonb), :s, now() + make_interval(mins => :ttl)) returning id, expires_at"),
        {"u": s.user_id, "r": run_id, "t": atype, "p": json.dumps(payload), "s": summary, "ttl": ttl})).mappings().one()
    return {"ok": True, "action_id": str(row["id"]), "summary": summary, "expires_at": row["expires_at"].isoformat()}


async def propose_book(conn, s: SessionContext, class_id, enforce: dict | None = None, run_id=None) -> dict:
    cls = await get_class(conn, class_id)
    if not cls or cls["status"] != "SCHEDULED" or cls["start_time"] <= now_utc():
        return {"ok": False, "error": "CLASS_UNAVAILABLE"}
    if cls["booked_count"] >= cls["capacity"]:
        return {"ok": False, "error": "CLASS_FULL", "hint": "offer_waitlist"}
    codes = set(await member_injury_codes(conn, s))
    warnings = []
    if cls["contraindicated_for"] and codes & set(cls["contraindicated_for"]):
        warnings.append("This class is flagged as unsuitable for an injury on your profile.")
    if enforce:  # chat path: constraints are enforced server-side, whatever the LLM asked for
        bad = set(enforce.get("codes", [])) & set(cls["contraindicated_for"] or [])
        if bad or IMPACT_RANK[cls["impact"]] > IMPACT_RANK[enforce.get("max_impact", "HIGH")] \
                or cls["category"] in enforce.get("avoid_categories", []):
            return {"ok": False, "error": "SAFETY_CONSTRAINT", "detail": "Class excluded by the member's safety constraints"}
    conflicts = await find_conflicts(conn, s.user_id, cls)
    if conflicts:
        return {"ok": False, "error": "CONFLICT", "conflicts": conflicts}
    ent = await entitlements(conn, s.user_id, cls["start_time"])
    if not ent["can_book"]:
        return {"ok": False, "error": "NO_ENTITLEMENT", "detail": ent["reason"]}
    dup = (await conn.execute(text("select 1 from class_bookings where user_id=:u and class_id=:c and status in ('CONFIRMED','WAITLISTED')"),
                              {"u": s.user_id, "c": cls["id"]})).scalar()
    if dup:
        return {"ok": False, "error": "ALREADY_BOOKED"}
    credit = f" Uses 1 class credit ({ent['remaining'] - 1} left after)." if ent["remaining"] is not None else " Included in your plan."
    summary = f"Book {cls['title']}, {fmt_local(cls['start_time'], s.timezone)}.{credit}"
    r = await create_pending(conn, s, "BOOK_CLASS", {"class_id": str(cls["id"])}, summary, run_id)
    if r["ok"] and warnings:
        r["warnings"] = warnings
    return r


async def propose_waitlist(conn, s: SessionContext, class_id, run_id=None) -> dict:
    cls = await get_class(conn, class_id)
    if not cls or cls["status"] != "SCHEDULED" or cls["start_time"] <= now_utc():
        return {"ok": False, "error": "CLASS_UNAVAILABLE"}
    if cls["booked_count"] < cls["capacity"]:
        return {"ok": False, "error": "CLASS_NOT_FULL", "hint": "book_directly"}
    dup = (await conn.execute(text("select 1 from class_bookings where user_id=:u and class_id=:c and status in ('CONFIRMED','WAITLISTED')"),
                              {"u": s.user_id, "c": cls["id"]})).scalar()
    if dup:
        return {"ok": False, "error": "ALREADY_BOOKED"}
    ent = await entitlements(conn, s.user_id, cls["start_time"])
    if not ent["can_book"]:
        return {"ok": False, "error": "NO_ENTITLEMENT", "detail": ent["reason"]}
    summary = f"Join the waitlist for {cls['title']}, {fmt_local(cls['start_time'], s.timezone)}. You are promoted automatically if a spot opens."
    return await create_pending(conn, s, "JOIN_WAITLIST", {"class_id": str(cls["id"])}, summary, run_id)


async def propose_cancel(conn, s: SessionContext, booking_id, run_id=None) -> dict:
    b = (await conn.execute(text(
        "select b.id, b.status::text as status, c.title, c.start_time from class_bookings b join fitness_classes c on c.id=b.class_id "
        "where b.id=cast(:b as uuid) and b.user_id=:u"), {"b": str(booking_id), "u": s.user_id})).mappings().first()
    if not b or b["status"] not in ("CONFIRMED", "WAITLISTED"):
        return {"ok": False, "error": "BOOKING_NOT_FOUND"}
    if b["start_time"] <= now_utc():
        return {"ok": False, "error": "CLASS_STARTED"}
    late_h = int(await gym_setting(conn, "late_cancel_hours", 2))
    is_late = b["start_time"] - now_utc() < timedelta(hours=late_h)
    pen = f" This is within {late_h} hours of the start; the studio's late-cancellation policy applies." if is_late else ""
    summary = f"Cancel your {'waitlist spot' if b['status']=='WAITLISTED' else 'booking'} for {b['title']}, {fmt_local(b['start_time'], s.timezone)}.{pen}"
    r = await create_pending(conn, s, "CANCEL_BOOKING", {"booking_id": str(b["id"])}, summary, run_id)
    if r["ok"]:
        r["is_late_cancel"] = is_late
    return r


# ------------------------------------------------------------------ notifications
TEMPLATES = {
    "CLASS_CONFIRMED": ("Booking confirmed", "Confirmed: {class_title} on {when}. Trainer: {trainer_name}."),
    "WAITLIST_PROMOTED": ("You're in!", "A spot opened in {class_title} ({when}). You're now confirmed."),
    "WAITLIST_REMOVED": ("Waitlist update", "We couldn't move you into {class_title} ({when}) because of a schedule or plan limit."),
    "BOOKING_CANCELLED": ("Booking cancelled", "Your booking for {class_title} ({when}) was cancelled."),
    "PLAN_CHANGED": ("Plan updated", "Your membership is now {plan}."),
}


async def enqueue(conn, user_id: str, template: str, params: dict, dedupe_key: str):
    await conn.execute(text(
        "insert into notification_outbox (user_id, template, params, dedupe_key) values (:u, :t, cast(:p as jsonb), :d) "
        "on conflict (dedupe_key) do nothing"), {"u": user_id, "t": template, "p": json.dumps(params), "d": dedupe_key})


async def flush_outbox(conn, batch=100) -> int:
    rows = (await conn.execute(text(
        "select id, user_id, template, params::text as params from notification_outbox where sent_at is null and send_after<=now() "
        "order by send_after limit :n for update skip locked"), {"n": batch})).mappings().all()
    for r in rows:
        title, body = TEMPLATES[r["template"]]
        try:
            msg = body.format(**json.loads(r["params"]))
        except KeyError:
            await conn.execute(text("update notification_outbox set attempts=attempts+1 where id=:i"), {"i": r["id"]}); continue
        await conn.execute(text("insert into notifications (user_id, title, message) values (:u,:t,:m)"), {"u": str(r["user_id"]), "t": title, "m": msg})
        await conn.execute(text("update notification_outbox set sent_at=now() where id=:i"), {"i": r["id"]})
    return len(rows)


# ------------------------------------------------------------------ executors (deterministic, re-validate everything)
async def user_lock(conn, user_id: str):
    await conn.execute(text("select pg_advisory_xact_lock(hashtextextended(:u, 0))"), {"u": user_id})


async def exec_book(conn, s, action) -> dict:
    cid = action["payload"]["class_id"]
    await user_lock(conn, s.user_id)                           # serialize one user's bookings (overlap races)
    cls = await get_class(conn, cid, lock=True)                # then lock the class row (capacity races)
    if not cls or cls["status"] != "SCHEDULED" or cls["start_time"] <= now_utc():
        return {"ok": False, "error": "CLASS_UNAVAILABLE"}
    if await find_conflicts(conn, s.user_id, cls):
        return {"ok": False, "error": "CONFLICT"}
    ent = await entitlements(conn, s.user_id, cls["start_time"])
    if not ent["can_book"]:
        return {"ok": False, "error": "NO_ENTITLEMENT", "detail": ent["reason"]}
    if cls["booked_count"] >= cls["capacity"]:
        return {"ok": False, "error": "CLASS_FULL", "hint": "offer_waitlist"}
    try:
        async with conn.begin_nested():
            b = (await conn.execute(text(
                "insert into class_bookings (user_id, class_id, status, idempotency_key) values (:u, :c, 'CONFIRMED', :k) returning id"),
                {"u": s.user_id, "c": cls["id"], "k": action["id"]})).scalar()
    except IntegrityError:
        return {"ok": False, "error": "ALREADY_BOOKED"}
    await conn.execute(text("update fitness_classes set booked_count = booked_count + 1 where id=:c"), {"c": cls["id"]})
    trainer = (await conn.execute(text("select full_name from users where id=:t"), {"t": cls["trainer_id"]})).scalar()
    await enqueue(conn, s.user_id, "CLASS_CONFIRMED",
                  {"class_title": cls["title"], "when": fmt_local(cls["start_time"], s.timezone), "trainer_name": trainer}, f"confirm:{b}")
    return {"ok": True, "booking_id": str(b), "status": "CONFIRMED"}


async def exec_waitlist(conn, s, action) -> dict:
    cid = action["payload"]["class_id"]
    await user_lock(conn, s.user_id)
    cls = await get_class(conn, cid, lock=True)
    if not cls or cls["status"] != "SCHEDULED" or cls["start_time"] <= now_utc():
        return {"ok": False, "error": "CLASS_UNAVAILABLE"}
    if cls["booked_count"] < cls["capacity"]:
        return {"ok": False, "error": "CLASS_NOT_FULL", "hint": "book_directly"}
    ent = await entitlements(conn, s.user_id, cls["start_time"])
    if not ent["can_book"]:
        return {"ok": False, "error": "NO_ENTITLEMENT", "detail": ent["reason"]}
    try:
        async with conn.begin_nested():
            b = (await conn.execute(text(
                "insert into class_bookings (user_id, class_id, status, idempotency_key) values (:u, :c, 'WAITLISTED', :k) returning id"),
                {"u": s.user_id, "c": cls["id"], "k": action["id"]})).scalar()
    except IntegrityError:
        return {"ok": False, "error": "ALREADY_BOOKED"}
    pos = (await conn.execute(text(
        "select count(*) from class_bookings where class_id=:c and status='WAITLISTED' and waitlist_seq <= "
        "(select waitlist_seq from class_bookings where id=:b)"), {"c": cls["id"], "b": b})).scalar()
    return {"ok": True, "booking_id": str(b), "status": "WAITLISTED", "position": pos}


async def promote_waitlist(conn, s, cls) -> str | None:
    """Fill ONE freed spot. Runs as SYSTEM (cross-user), inside the cancel transaction; skips ineligible members."""
    tz = await gym_setting(conn, "timezone", "UTC")
    async with as_system(conn, s.user_id, s.role):
        cands = (await conn.execute(text(
            "select id, user_id from class_bookings where class_id=:c and status='WAITLISTED' "
            "order by waitlist_seq for update skip locked"), {"c": cls["id"]})).mappings().all()
        for c in cands:
            uid = str(c["user_id"])
            got = (await conn.execute(text("select pg_try_advisory_xact_lock(hashtextextended(:u, 0))"), {"u": uid})).scalar()
            if not got:     # that member is mid-transaction elsewhere; never wait (avoids lock-order deadlocks)
                continue
            ent = await entitlements(conn, uid, cls["start_time"])
            if not ent["can_book"] or await find_conflicts(conn, uid, cls):
                await conn.execute(text("update class_bookings set status='CANCELLED', cancelled_at=now() where id=:i"), {"i": c["id"]})
                await enqueue(conn, uid, "WAITLIST_REMOVED", {"class_title": cls["title"], "when": fmt_local(cls["start_time"], tz)}, f"wlrm:{c['id']}")
                continue
            await conn.execute(text("update class_bookings set status='CONFIRMED' where id=:i"), {"i": c["id"]})
            await conn.execute(text("update fitness_classes set booked_count = booked_count + 1 where id=:c"), {"c": cls["id"]})
            await enqueue(conn, uid, "WAITLIST_PROMOTED", {"class_title": cls["title"], "when": fmt_local(cls["start_time"], tz)}, f"promo:{c['id']}")
            return uid
    return None


async def exec_cancel(conn, s, action) -> dict:
    bid = action["payload"]["booking_id"]
    row = (await conn.execute(text("select class_id from class_bookings where id=cast(:b as uuid) and user_id=:u"),
                              {"b": bid, "u": s.user_id})).mappings().first()
    if not row:
        return {"ok": False, "error": "BOOKING_NOT_FOUND"}
    cls = await get_class(conn, row["class_id"], lock=True)    # class lock first (same order as booking)
    b = (await conn.execute(text("select id, status::text as status from class_bookings where id=cast(:b as uuid) and user_id=:u for update"),
                            {"b": bid, "u": s.user_id})).mappings().first()
    if not b or b["status"] not in ("CONFIRMED", "WAITLISTED"):
        return {"ok": False, "error": "BOOKING_NOT_FOUND"}
    if cls["start_time"] <= now_utc():
        return {"ok": False, "error": "CLASS_STARTED"}
    late_h = int(await gym_setting(conn, "late_cancel_hours", 2))
    late = cls["start_time"] - now_utc() < timedelta(hours=late_h)
    await conn.execute(text("update class_bookings set status='CANCELLED', cancelled_at=now() where id=cast(:b as uuid)"), {"b": bid})
    promoted = None
    if b["status"] == "CONFIRMED":
        await conn.execute(text("update fitness_classes set booked_count = booked_count - 1 where id=:c"), {"c": cls["id"]})
        promoted = await promote_waitlist(conn, s, cls)
    return {"ok": True, "status": "CANCELLED", "late_cancel": late, "waitlist_promoted": promoted is not None}


async def exec_save_nutrition(conn, s, action) -> dict:
    p = action["payload"]
    await conn.execute(text(
        "insert into nutrition_plans (user_id, dietary_preference, target_calories, protein_grams, carb_grams, fat_grams, meal_plan_details, prompt_version) "
        "values (:u, :d, :k, :p, :c, :f, cast(:m as jsonb), :v)"),
        {"u": s.user_id, "d": p["dietary_preference"], "k": p["daily_calories"], "p": p["macros"]["protein_g"], "c": p["macros"]["carbs_g"],
         "f": p["macros"]["fats_g"], "m": json.dumps(p["meals"]), "v": "deterministic-1.0"})
    return {"ok": True}


async def plan_pricing(conn, s, to_plan: str, cycle: str) -> dict:
    plans = {r["code"]: r for r in (await conn.execute(text(
        "select code, price_monthly, price_annual, currency, sort_order from membership_plans where is_active"))).mappings().all()}
    if to_plan not in plans:
        return {"ok": False, "error": "UNKNOWN_PLAN"}
    new_price = plans[to_plan]["price_monthly"] if cycle == "MONTHLY" else plans[to_plan]["price_annual"]
    if new_price is None:
        return {"ok": False, "error": "CYCLE_NOT_AVAILABLE"}
    cur = (await conn.execute(text(
        "select id, plan_code, billing_cycle::text as cycle, price_paid, start_date, end_date from memberships where user_id=:u and status='ACTIVE' and end_date>=current_date"),
        {"u": s.user_id})).mappings().first()
    if cur and cur["plan_code"] == to_plan and cur["cycle"] == cycle:
        return {"ok": False, "error": "NO_CHANGE"}
    if cur and plans[to_plan]["sort_order"] < plans[cur["plan_code"]]["sort_order"]:
        return {"ok": False, "error": "HUMAN_SUPPORT_REQUIRED", "detail": "Downgrades are handled by our team at renewal."}
    charge = float(new_price)
    if cur:
        period = max(1, (cur["end_date"] - cur["start_date"]).days)
        remaining = max(0, (cur["end_date"] - date.today()).days)
        charge = round(max(0.0, float(new_price) - float(cur["price_paid"])) * remaining / period, 2) if cur["cycle"] == cycle else float(new_price)
    return {"ok": True, "new_price": float(new_price), "charge_today": charge, "currency": plans[to_plan]["currency"], "current": jsonable(dict(cur)) if cur else None}


async def propose_plan_change(conn, s, to_plan: str, cycle: str, run_id=None) -> dict:
    pr = await plan_pricing(conn, s, to_plan, cycle)
    if not pr["ok"]:
        return pr
    verb = "Upgrade to" if pr["current"] else "Subscribe to"
    summary = (f"{verb} {to_plan} ({cycle.lower()}). Charge today: {pr['charge_today']:.2f} {pr['currency']}. "
               f"New price: {pr['new_price']:.2f} {pr['currency']} per {'month' if cycle=='MONTHLY' else 'year'}.")
    r = await create_pending(conn, s, "CHANGE_PLAN", {"plan_code": to_plan, "cycle": cycle}, summary, run_id)
    if r["ok"]:
        r["charge_today"] = pr["charge_today"]
    return r


async def exec_change_plan(conn, s, action) -> dict:
    to_plan, cycle = action["payload"]["plan_code"], action["payload"]["cycle"]
    await user_lock(conn, s.user_id)
    pr = await plan_pricing(conn, s, to_plan, cycle)       # re-priced at execution time
    if not pr["ok"]:
        return pr
    if pr["charge_today"] > 0 and settings.env == "production":
        return {"ok": False, "error": "PAYMENT_PROVIDER_NOT_CONFIGURED"}   # never grant paid plans for free in prod
    days = 30 if cycle == "MONTHLY" else 365
    if pr["current"]:
        await conn.execute(text("update memberships set status='CANCELLED' where id=cast(:i as uuid)"), {"i": pr["current"]["id"]})
    await conn.execute(text(
        "insert into memberships (user_id, plan_code, status, billing_cycle, price_paid, start_date, end_date) "
        "values (:u, :p, 'ACTIVE', cast(:c as billing_cycle_type), :pp, current_date, current_date + cast(:d as int))"),
        {"u": s.user_id, "p": to_plan, "c": cycle, "pp": pr["new_price"], "d": days})
    await enqueue(conn, s.user_id, "PLAN_CHANGED", {"plan": to_plan}, f"plan:{action['id']}")
    return {"ok": True, "plan": to_plan, "charged": pr["charge_today"]}


EXECUTORS = {"BOOK_CLASS": exec_book, "JOIN_WAITLIST": exec_waitlist, "CANCEL_BOOKING": exec_cancel,
             "SAVE_NUTRITION_PLAN": exec_save_nutrition, "CHANGE_PLAN": exec_change_plan}


async def confirm_action(conn, s: SessionContext, action_id) -> tuple[int, dict]:
    a = (await conn.execute(text(
        "select id, type::text as type, payload, status::text as status, expires_at, result from pending_actions "
        "where id=cast(:i as uuid) and user_id=:u for update"), {"i": str(action_id), "u": s.user_id})).mappings().first()
    if not a:
        return 404, {"error": "ACTION_NOT_FOUND"}
    if a["status"] in ("EXECUTED", "FAILED"):
        return 200, {**(a["result"] or {}), "replayed": True}      # idempotent replay (double-click, retry)
    if a["status"] != "PENDING":
        return 409, {"error": f"ACTION_{a['status']}"}
    if a["expires_at"] <= now_utc():
        await conn.execute(text("update pending_actions set status='EXPIRED' where id=:i"), {"i": a["id"]})
        return 409, {"error": "ACTION_EXPIRED"}
    res = await EXECUTORS[a["type"]](conn, s, dict(a))
    await conn.execute(text("update pending_actions set status=:st, result=cast(:r as jsonb), executed_at=now() where id=:i"),
                       {"st": "EXECUTED" if res["ok"] else "FAILED", "r": json.dumps(res), "i": a["id"]})
    await conn.execute(text("insert into audit_log (actor_id, action, entity, entity_id, details) values (:u, :a, 'pending_actions', :e, cast(:d as jsonb))"),
                       {"u": s.user_id, "a": f"EXEC_{a['type']}", "e": a["id"], "d": json.dumps({"ok": res["ok"], "error": res.get("error")})})
    return 200, res
