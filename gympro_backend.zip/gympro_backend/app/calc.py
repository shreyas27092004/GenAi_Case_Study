"""Deterministic calculators. The LLM never produces these numbers."""
ACTIVITY = {"SEDENTARY": 1.2, "LIGHT": 1.375, "MODERATE": 1.55, "VERY_ACTIVE": 1.725}
SPLITS = {  # protein / carbs / fat shares of calories
    "FAT_LOSS": (0.40, 0.35, 0.25), "MUSCLE_GAIN": (0.30, 0.50, 0.20),
    "KETO": (0.25, 0.05, 0.70), "BALANCED": (0.25, 0.50, 0.25),
}


def bmr(weight_kg: float, height_cm: float, age: int, sex: str) -> float:
    base = 10 * weight_kg + 6.25 * height_cm - 5 * age
    return round(base + 5 if sex == "MALE" else base - 161, 1)  # OTHER/UNSPECIFIED use the conservative (lower) female constant


def tdee(bmr_val: float, activity: str) -> float:
    return round(bmr_val * ACTIVITY[activity], 1)


def bmi(weight_kg: float, height_cm: float) -> dict:
    v = round(weight_kg / ((height_cm / 100) ** 2), 1)
    cat = "underweight" if v < 18.5 else "healthy range" if v < 25 else "above healthy range" if v < 30 else "well above healthy range"
    return {"bmi": v, "category": cat, "note": "BMI ignores muscle mass and body composition."}


def hydration_ml(weight_kg: float, class_minutes: int = 0) -> int:
    return int(min(5000, round(35 * weight_kg + 500 * (class_minutes / 45))))


def macros(target_kcal: int, split: str) -> dict:
    p, c, f = SPLITS[split]
    pg, cg, fg = round(target_kcal * p / 4), round(target_kcal * c / 4), round(target_kcal * f / 9)
    return {"protein_g": pg, "carbs_g": cg, "fats_g": fg, "kcal_check": pg * 4 + cg * 4 + fg * 9}


def calorie_floor(sex: str) -> int:
    return 1500 if sex == "MALE" else 1200
