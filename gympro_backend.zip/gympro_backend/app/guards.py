"""Deterministic input guards. Defense in depth only: the REAL controls are the tool layer, RLS and the confirm boundary."""
import re

EMERGENCY = re.compile(r"(chest (pain|pressure|tightness|feels? tight)|tight(ness)? in (my )?chest|can'?t breathe|trouble breathing|"
                       r"short(ness)? of breath|fainted|passed out|pass out|blacking out|dizz(y|iness)|face (is )?(droop|numb)|"
                       r"numb(ness)? (in|on) (my )?(arm|face|leg)|slurred speech|heart (is )?racing|palpitations|"
                       r"coughing (up )?blood|severe bleeding|broke my (leg|arm|ankle|wrist|rib|collarbone)|broken (bone|leg|arm)|can'?t (put weight|walk on))", re.I)
CRISIS = re.compile(r"(suicid|kill myself|end my life|want to die|self[- ]?harm|hurt myself|no reason to live|being abused|abusing me)", re.I)
ED = re.compile(r"(starv(e|ing) myself|purg(e|ing)|make myself (throw up|vomit)|burn off (what i ate|my food)|"
                r"(eat|eating) (nothing|under \d{3} cal)|laxatives? to lose|hate (my )?body.*(skip|stop eating))", re.I)
INJECTION = re.compile(r"(ignore (all |any |the |your )?(previous |prior |above )?(instructions|rules)|disregard (all |your )?(rules|instructions)|"
                       r"you are now|act as (an? )?(admin|root|system)|system prompt|developer (message|mode)|reveal your (prompt|instructions)|"
                       r"jailbreak|override (safety|the rules))", re.I)
CROSS_USER = re.compile(r"(for|of|as|on behalf of)\s+(another|other|someone else|a different)\s+(user|member|person|account)|"
                        r"(someone else'?s|another (user|member)'?s?|other (users|members)'?)\s+(booking|data|account|profile|health|plan)|"
                        r"\b(user|member)[ _-]?id\s*[:=]?\s*[0-9a-f]{8}-?[0-9a-f]{4}", re.I)
SAFETY_TERMS = re.compile(r"\b(pain|painful|injur\w*|hurt\w*|sore|strain\w*|sprain\w*|knee|ankle|shoulder|wrist|neck|doctor|physio\w*|"
                          r"pregnan\w*|surgery)\b", re.I)

EMERGENCY_REPLY = ("What you describe could be serious and needs medical attention before any exercise. Please contact a doctor promptly, "
                   "and call your local emergency number (for example 112, 911 or 999) if symptoms are severe, return, or worsen. "
                   "I've paused workout planning for now.")
CRISIS_REPLY = ("I'm really sorry you're going through this. You deserve support from a person right now. If you might act on these thoughts, "
                "please call your local emergency number. In India you can reach Tele-MANAS at 14416; in the US call or text 988. "
                "If you can, tell someone you trust how you're feeling today.")
ED_REPLY = ("I'm not able to help with restricting food or compensating for eating, and I'm concerned about how you're feeling. "
            "A doctor or a registered dietitian can support you. In the US, the National Alliance for Eating Disorders helpline is 1-866-662-1235. "
            "I'm happy to help with gentle, balanced training whenever you're ready.")
REFUSE_REPLY = "I can only help with your own account and data. Tell me what you'd like to do for yourself and I'll set it up."
SCOPE_REPLY = ("I can help with classes and bookings, trainers, workouts, wellness and nutrition guidance, and your membership. "
               "What would you like to do?")


def classify(message: str) -> dict:
    labels = []
    if CRISIS.search(message):
        labels.append("CRISIS")
    if EMERGENCY.search(message):
        labels.append("MEDICAL_EMERGENCY")
    if ED.search(message):
        labels.append("EATING_DISORDER")
    if INJECTION.search(message):
        labels.append("PROMPT_INJECTION")
    if CROSS_USER.search(message):
        labels.append("CROSS_USER_REQUEST")
    route, reply = "CONTINUE", None
    if "CRISIS" in labels:
        route, reply = "ESCALATE", CRISIS_REPLY
    elif "MEDICAL_EMERGENCY" in labels:
        route, reply = "ESCALATE", EMERGENCY_REPLY
    elif "EATING_DISORDER" in labels:
        route, reply = "ESCALATE", ED_REPLY
    elif "CROSS_USER_REQUEST" in labels:
        route, reply = "REFUSE", REFUSE_REPLY
    return {"labels": labels or ["BENIGN"], "route": route, "reply": reply}


# ---- planner (deterministic rules). Word boundaries, not substrings.
RULES = {
    "SCHEDULE": re.compile(r"\b(book|booking|bookings|cancel|waitlist|reschedule|class|classes|session|slot|tomorrow|tonight|today|yoga|pilates|hiit|zumba|spin|swim\w*)\b", re.I),
    "TRAINER": re.compile(r"\b(trainer|trainers|coach|coaches|instructor|certified|certification)\b", re.I),
    "FITNESS": re.compile(r"\b(workout plan|routine|beginner|fat loss plan|training plan|roadmap|program|regimen)\b", re.I),
    "HEALTH": re.compile(r"\b(pain|painful|injur\w*|hurt\w*|sore|strain\w*|sprain\w*|knee|ankle|shoulder|wrist|neck|bmi|bmr|tdee|hydrat\w*|water intake|calories? (do i|should i) burn)\b", re.I),
    "MEMBERSHIP": re.compile(r"\b(membership|renew\w*|upgrade|downgrade|gold|silver|platinum|plan price|subscription)\b", re.I),
    "NUTRITION": re.compile(r"\b(diet|meal|meals|macro|macros|nutrition|protein intake|vegetarian|vegan|keto|calorie target)\b", re.I),
    "ANALYTICS": re.compile(r"\b(occupancy|revenue|mrr|analytics|peak hours|utili[sz]ation|fill rate)\b", re.I),
}
BACK_PAIN = re.compile(r"\b(back (pain|ache|strain|hurts?)|lower back|sore back)\b", re.I)


def plan(message: str, role: str) -> dict:
    hits = [a for a, rx in RULES.items() if rx.search(message)]
    if BACK_PAIN.search(message) and "HEALTH" not in hits:
        hits.append("HEALTH")
    if SAFETY_TERMS.search(message) and "HEALTH" not in hits and any(a in hits for a in ("SCHEDULE", "FITNESS", "NUTRITION")):
        hits.append("HEALTH")
    if "ANALYTICS" in hits and role != "ADMIN":
        return {"route": "REFUSE", "reply": "Business analytics are only available to gym administrators.", "waves": []}
    if not hits:
        return {"route": "CLARIFY", "reply": SCOPE_REPLY, "waves": []}
    hits = hits[:4]
    if "HEALTH" in hits and len(hits) > 1:
        waves = [["HEALTH"], [h for h in hits if h != "HEALTH"]]
    else:
        waves = [hits]
    return {"route": "CONTINUE", "reply": None, "waves": waves}
