# GymPro backend (tested reference implementation)

```bash
# 1. Postgres 15+ (superuser steps)
createdb gympro
psql -d gympro -c "CREATE EXTENSION btree_gist; CREATE EXTENSION citext; CREATE EXTENSION pgcrypto;"
psql -d gympro -v ON_ERROR_STOP=1 -f schema.sql -f roles.sql      # change the gympro_app password in roles.sql first!

# 2. App
python -m venv venv && source venv/bin/activate && pip install -r requirements.txt
cp .env.example .env     # set JWT_SECRET, DATABASE_URL, LLM_*
ADMIN_EMAIL=you@yourco.com ADMIN_PASSWORD='at-least-12-chars' python -m app.seed
uvicorn app.main:app --port 8000        # docs at /docs

# 3. Tests (they DROP and recreate the public schema of the "gympro" DB on localhost as user postgres/postgres: use a throwaway DB!)
pytest -q
```
Without an LLM (`LLM_PROVIDER=none`) every REST endpoint works; the chat endpoint still handles emergencies, crisis, eating-disorder, cross-user and out-of-scope messages deterministically and returns 503 for requests that need the AI.
