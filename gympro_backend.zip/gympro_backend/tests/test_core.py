import asyncio, uuid, jwt
from datetime import datetime, timedelta, timezone
from conftest import PW, mk_class
from app.settings import settings


# ------------------------------------------------------------------ auth
async def test_health(client):
    assert (await client.get("/health")).json() == {"status": "ok"}


async def test_register_login_me(client):
    r = await client.post("/api/auth/register", json={"email": "a@x.com", "password": PW, "full_name": "A"})
    assert r.status_code == 201
    r = await client.post("/api/auth/login", json={"email": "a@x.com", "password": PW})
    assert r.status_code == 200
    me = await client.get("/api/me", headers={"Authorization": f"Bearer {r.json()['token']}"})
    assert me.json()["role"] == "MEMBER" and me.json()["email"] == "a@x.com"


async def test_register_cannot_set_role_or_weak_password(client):
    r = await client.post("/api/auth/register", json={"email": "b@x.com", "password": PW, "full_name": "B", "role": "ADMIN"})
    assert r.status_code == 422                                  # extra field rejected, not ignored
    r = await client.post("/api/auth/register", json={"email": "c@x.com", "password": "short", "full_name": "C"})
    assert r.status_code == 422
    r = await client.post("/api/auth/register", json={"email": "c@x.com", "password": "alllowercase123", "full_name": "C"})
    assert r.status_code == 422


async def test_duplicate_email_and_bad_login(client):
    await client.post("/api/auth/register", json={"email": "d@x.com", "password": PW, "full_name": "D"})
    assert (await client.post("/api/auth/register", json={"email": "D@x.com", "password": PW, "full_name": "D"})).status_code == 409   # citext
    assert (await client.post("/api/auth/login", json={"email": "d@x.com", "password": "wrong-Pass1"})).status_code == 401
    assert (await client.post("/api/auth/login", json={"email": "nobody@x.com", "password": PW})).status_code == 401


async def test_token_attacks(client, users, sql):
    m = await users.member()
    assert (await client.get("/api/me")).status_code == 401
    assert (await client.get("/api/me", headers={"Authorization": "Bearer garbage"})).status_code == 401
    forged = jwt.encode({"sub": m.id, "aud": "gympro", "exp": datetime.now(timezone.utc) + timedelta(hours=1)}, "wrong-secret-wrong-secret-wrong-1", algorithm="HS256")
    assert (await client.get("/api/me", headers={"Authorization": f"Bearer {forged}"})).status_code == 401
    none_alg = jwt.encode({"sub": m.id, "aud": "gympro", "exp": datetime.now(timezone.utc) + timedelta(hours=1)}, None, algorithm="none")
    assert (await client.get("/api/me", headers={"Authorization": f"Bearer {none_alg}"})).status_code == 401
    expired = jwt.encode({"sub": m.id, "aud": "gympro", "exp": datetime.now(timezone.utc) - timedelta(seconds=5)}, settings.jwt_secret, algorithm="HS256")
    assert (await client.get("/api/me", headers={"Authorization": f"Bearer {expired}"})).status_code == 401
    await sql.run("UPDATE users SET is_active=false WHERE id=$1", uuid.UUID(m.id))     # revoked users lose access immediately
    assert (await client.get("/api/me", headers=m.h)).status_code == 401


async def test_login_rate_limited(client):
    codes = [(await client.post("/api/auth/login", json={"email": "z@x.com", "password": "x"})).status_code for _ in range(12)]
    assert 429 in codes


# ------------------------------------------------------------------ profile & RBAC
async def test_profile_roundtrip_and_validation(client, users):
    m = await users.member(profile=True, known_injuries=["KNEE"], allergies=["Peanut"])
    p = (await client.get("/api/me/profile", headers=m.h)).json()
    assert p["known_injuries"] == ["KNEE"] and p["allergies"] == ["peanut"] and p["health_data_consent_at"]
    bad = {"date_of_birth": "2020-01-01", "height_cm": 175, "weight_kg": 75}
    assert (await client.put("/api/me/profile", json=bad, headers=m.h)).status_code == 422       # too young (<12)
    bad = {"date_of_birth": "1990-01-01", "height_cm": 20, "weight_kg": 75}
    assert (await client.put("/api/me/profile", json=bad, headers=m.h)).status_code == 422
    bad = {"date_of_birth": "1990-01-01", "height_cm": 170, "weight_kg": 70, "known_injuries": ["FOOT"]}
    assert (await client.put("/api/me/profile", json=bad, headers=m.h)).status_code == 422


async def test_rbac_matrix(client, users):
    m = await users.member(); t = await users.staff("TRAINER"); a = await users.staff("ADMIN")
    for path in ("/api/admin/analytics/mrr", "/api/admin/analytics/occupancy_rate"):
        assert (await client.get(path, headers=m.h)).status_code == 403
        assert (await client.get(path, headers=t.h)).status_code == 403
        assert (await client.get(path, headers=a.h)).status_code == 200
    assert (await client.post("/api/admin/users", json={"email": "n@x.com", "password": PW, "full_name": "N", "role": "ADMIN"}, headers=m.h)).status_code == 403
    assert (await client.get("/api/bookings", headers=t.h)).status_code == 403      # staff aren't members
    assert (await client.post("/api/admin/outbox/flush", headers=m.h)).status_code == 403


# ------------------------------------------------------------------ classes
async def test_class_admin_create_list_detail(client, users, sql):
    a = await users.staff("ADMIN"); t = await users.staff("TRAINER"); m = await users.member()
    start = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
    end = (datetime.now(timezone.utc) + timedelta(days=1, hours=1)).isoformat()
    body = {"title": "HIIT", "trainer_id": t.id, "category": "HIIT", "impact": "HIGH", "capacity": 5, "start_time": start, "end_time": end}
    assert (await client.post("/api/admin/classes", json=body, headers=m.h)).status_code == 403
    r = await client.post("/api/admin/classes", json=body, headers=a.h)
    assert r.status_code == 201
    cid = r.json()["class_id"]
    # trainer double-booking blocked by exclusion constraint
    assert (await client.post("/api/admin/classes", json=body, headers=a.h)).status_code == 409
    lst = (await client.get("/api/classes", headers=m.h)).json()["classes"]
    assert [c["id"] for c in lst] == [cid] and lst[0]["spots_left"] == 5
    assert (await client.get(f"/api/classes/{cid}", headers=m.h)).status_code == 200
    assert (await client.get(f"/api/classes/{uuid.uuid4()}", headers=m.h)).status_code == 404
    past = {**body, "start_time": (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat(), "end_time": (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()}
    assert (await client.post("/api/admin/classes", json=past, headers=a.h)).status_code == 422
    assert (await client.get("/api/classes?category=NOPE", headers=m.h)).status_code == 422
    # trainers can only create for themselves
    other = await users.staff("TRAINER")
    assert (await client.post("/api/admin/classes", json={**body, "trainer_id": other.id}, headers=t.h)).status_code == 403


# ------------------------------------------------------------------ bookings
async def book(client, user, cid):
    r = await client.post("/api/bookings/propose", json={"class_id": cid}, headers=user.h)
    if r.status_code != 201:
        return r
    return await client.post(f"/api/actions/{r.json()['action_id']}/confirm", headers=user.h)


async def test_booking_happy_path_notifications_and_replay(client, users, sql):
    t = await users.staff("TRAINER"); m = await users.member(); a = await users.staff("ADMIN")
    cid = await mk_class(sql, t.id)
    p = await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m.h)
    assert p.status_code == 201 and "Book Yoga" in p.json()["summary"]
    assert (await sql.val("SELECT booked_count FROM fitness_classes WHERE id=$1", uuid.UUID(cid))) == 0     # proposal changes nothing
    aid = p.json()["action_id"]
    r1 = await client.post(f"/api/actions/{aid}/confirm", headers=m.h)
    r2 = await client.post(f"/api/actions/{aid}/confirm", headers=m.h)           # double click / retry
    assert r1.status_code == 200 and r1.json()["status"] == "CONFIRMED"
    assert r2.status_code == 200 and r2.json()["replayed"] and r2.json()["booking_id"] == r1.json()["booking_id"]
    assert (await sql.val("SELECT booked_count FROM fitness_classes WHERE id=$1", uuid.UUID(cid))) == 1
    assert (await sql.val("SELECT count(*) FROM class_bookings")) == 1
    assert (await client.post("/api/admin/outbox/flush", headers=a.h)).json()["delivered"] == 1
    n = (await client.get("/api/notifications", headers=m.h)).json()["notifications"]
    assert len(n) == 1 and "Confirmed: Yoga" in n[0]["message"]
    assert (await client.post(f"/api/notifications/{n[0]['id']}/read", headers=m.h)).status_code == 200
    # duplicate booking blocked
    assert (await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m.h)).status_code == 409


async def test_booking_rules(client, users, sql):
    t = await users.staff("TRAINER"); t2 = await users.staff("TRAINER"); t3 = await users.staff("TRAINER"); t4 = await users.staff("TRAINER")
    m = await users.member(); nomem = await users.member("nomem", plan=None)
    c1 = await mk_class(sql, t.id, "A", start_h=24); c2 = await mk_class(sql, t2.id, "B", start_h=24.5)      # overlaps A for same member
    assert (await book(client, m, c1)).status_code == 200
    r = await client.post("/api/bookings/propose", json={"class_id": c2}, headers=m.h)
    assert r.status_code == 409 and r.json()["detail"]["error"] == "CONFLICT"
    c3 = await mk_class(sql, t3.id, "C", start_h=25.1)                  # starts 6 min after A ends -> inside 15 min buffer
    assert (await client.post("/api/bookings/propose", json={"class_id": c3}, headers=m.h)).status_code == 409
    c4 = await mk_class(sql, t4.id, "D", start_h=25.5)                  # 30 min gap -> fine
    assert (await client.post("/api/bookings/propose", json={"class_id": c4}, headers=m.h)).status_code == 201
    r = await client.post("/api/bookings/propose", json={"class_id": c1}, headers=nomem.h)
    assert r.status_code == 409 and r.json()["detail"]["error"] == "NO_ENTITLEMENT"
    past = await mk_class(sql, t.id, "P", start_h=-3)
    assert (await client.post("/api/bookings/propose", json={"class_id": past}, headers=m.h)).status_code == 404
    assert (await client.post("/api/bookings/propose", json={"class_id": str(uuid.uuid4())}, headers=m.h)).status_code == 404
    assert (await client.post("/api/bookings/propose", json={"class_id": c1, "user_id": nomem.id}, headers=m.h)).status_code == 422   # no user_id smuggling


async def test_silver_monthly_limit(client, users, sql):
    t = await users.staff("TRAINER"); m = await users.member(plan="SILVER")
    ids = [await mk_class(sql, t.id, f"S{i}", start_h=24 * 3 + i * 3) for i in range(5)]
    # all within one calendar month in most cases; force same month check by reading what happened
    results = [(await book(client, m, c)).status_code for c in ids]
    ok = results.count(200)
    assert ok <= 4 and (ok == 4 and 409 in results or ok < 4)


async def test_action_ownership_expiry_reject(client, users, sql):
    t = await users.staff("TRAINER"); m1 = await users.member("m1"); m2 = await users.member("m2")
    cid = await mk_class(sql, t.id)
    aid = (await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m1.h)).json()["action_id"]
    assert (await client.post(f"/api/actions/{aid}/confirm", headers=m2.h)).status_code == 404      # can't confirm someone else's action (RLS + filter)
    assert (await client.post(f"/api/actions/{aid}/reject", headers=m2.h)).status_code == 404
    await sql.run("UPDATE pending_actions SET expires_at = now() - interval '1 minute' WHERE id=$1", uuid.UUID(aid))
    r = await client.post(f"/api/actions/{aid}/confirm", headers=m1.h)
    assert r.status_code == 409 and r.json()["detail"]["error"] == "ACTION_EXPIRED"
    aid2 = (await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m1.h)).json()["action_id"]
    assert (await client.post(f"/api/actions/{aid2}/reject", headers=m1.h)).status_code == 200
    assert (await client.post(f"/api/actions/{aid2}/confirm", headers=m1.h)).status_code == 409
    assert (await sql.val("SELECT count(*) FROM class_bookings")) == 0


async def test_pending_cap_and_idempotent_proposal(client, users, sql):
    t = await users.staff("TRAINER"); m = await users.member()
    ids = [await mk_class(sql, t.id, f"X{i}", start_h=24 + i * 3) for i in range(7)]
    a1 = (await client.post("/api/bookings/propose", json={"class_id": ids[0]}, headers=m.h)).json()["action_id"]
    a2 = (await client.post("/api/bookings/propose", json={"class_id": ids[0]}, headers=m.h)).json()["action_id"]
    assert a1 == a2
    codes = [(await client.post("/api/bookings/propose", json={"class_id": c}, headers=m.h)).status_code for c in ids[1:]]
    assert 429 in codes


# ------------------------------------------------------------------ concurrency
async def test_last_spot_race(client, users, sql):
    t = await users.staff("TRAINER")
    cid = await mk_class(sql, t.id, cap=1)
    members = [await users.member(f"r{i}") for i in range(8)]
    aids = [(await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m.h)).json()["action_id"] for m in members]
    res = await asyncio.gather(*[client.post(f"/api/actions/{a}/confirm", headers=m.h) for a, m in zip(aids, members)])
    codes = sorted(r.status_code for r in res)
    assert codes.count(200) == 1 and codes.count(409) == 7
    assert (await sql.val("SELECT count(*) FROM class_bookings WHERE status='CONFIRMED'")) == 1
    assert (await sql.val("SELECT booked_count FROM fitness_classes WHERE id=$1", uuid.UUID(cid))) == 1


async def test_same_user_overlap_race(client, users, sql):
    t = await users.staff("TRAINER"); t2 = await users.staff("TRAINER"); m = await users.member()
    c1 = await mk_class(sql, t.id, "O1", start_h=24); c2 = await mk_class(sql, t2.id, "O2", start_h=24.5)
    # create both proposals BEFORE either is confirmed (propose-time conflict check passes for both)
    a1 = (await client.post("/api/bookings/propose", json={"class_id": c1}, headers=m.h)).json()["action_id"]
    a2 = (await client.post("/api/bookings/propose", json={"class_id": c2}, headers=m.h)).json()["action_id"]
    res = await asyncio.gather(client.post(f"/api/actions/{a1}/confirm", headers=m.h), client.post(f"/api/actions/{a2}/confirm", headers=m.h))
    assert sorted(r.status_code for r in res) == [200, 409]
    assert (await sql.val("SELECT count(*) FROM class_bookings WHERE status='CONFIRMED'")) == 1


async def test_double_confirm_race_single_booking(client, users, sql):
    t = await users.staff("TRAINER"); m = await users.member(); cid = await mk_class(sql, t.id)
    aid = (await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m.h)).json()["action_id"]
    res = await asyncio.gather(*[client.post(f"/api/actions/{aid}/confirm", headers=m.h) for _ in range(6)])
    assert all(r.status_code == 200 for r in res)
    assert (await sql.val("SELECT count(*) FROM class_bookings")) == 1
    assert (await sql.val("SELECT booked_count FROM fitness_classes WHERE id=$1", uuid.UUID(cid))) == 1


# ------------------------------------------------------------------ waitlist, cancel, promotion
async def test_waitlist_promotion_fifo(client, users, sql):
    t = await users.staff("TRAINER"); a = await users.staff("ADMIN")
    cid = await mk_class(sql, t.id, cap=1)
    m1, m2, m3 = [await users.member(n) for n in ("w1", "w2", "w3")]
    assert (await book(client, m1, cid)).status_code == 200
    # booking directly a full class is refused; waitlist is a separate, explicit action
    assert (await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m2.h)).status_code == 409
    for m in (m2, m3):
        r = await client.post(f"/api/classes/{cid}/waitlist-propose", headers=m.h)
        assert r.status_code == 201
        c = await client.post(f"/api/actions/{r.json()['action_id']}/confirm", headers=m.h)
        assert c.status_code == 200 and c.json()["status"] == "WAITLISTED"
    assert (await client.post(f"/api/classes/{cid}/waitlist-propose", headers=m2.h)).status_code == 409   # already waitlisted
    bid = (await client.get("/api/bookings", headers=m1.h)).json()["bookings"][0]["booking_id"]
    cp = await client.post(f"/api/bookings/{bid}/cancel-propose", headers=m1.h)
    cc = await client.post(f"/api/actions/{cp.json()['action_id']}/confirm", headers=m1.h)
    assert cc.json()["waitlist_promoted"] is True
    st = {r["user_id"]: r["status"] for r in await sql.all("SELECT user_id, status::text FROM class_bookings WHERE status<>'CANCELLED'")}
    assert st == {uuid.UUID(m2.id): "CONFIRMED", uuid.UUID(m3.id): "WAITLISTED"}                 # FIFO
    assert (await sql.val("SELECT booked_count FROM fitness_classes WHERE id=$1", uuid.UUID(cid))) == 1
    await client.post("/api/admin/outbox/flush", headers=a.h)
    assert any("now confirmed" in n["message"] for n in (await client.get("/api/notifications", headers=m2.h)).json()["notifications"])
    # another member's booking can't be cancel-proposed
    assert (await client.post(f"/api/bookings/{bid}/cancel-propose", headers=m3.h)).status_code == 404


async def test_waitlist_skips_ineligible_member(client, users, sql):
    t = await users.staff("TRAINER"); cid = await mk_class(sql, t.id, cap=1)
    m1 = await users.member("e1"); m2 = await users.member("e2"); m3 = await users.member("e3")
    await book(client, m1, cid)
    for m in (m2, m3):
        a = (await client.post(f"/api/classes/{cid}/waitlist-propose", headers=m.h)).json()["action_id"]
        await client.post(f"/api/actions/{a}/confirm", headers=m.h)
    await sql.run("UPDATE memberships SET status='EXPIRED' WHERE user_id=$1", uuid.UUID(m2.id))   # m2 lapses while waiting
    bid = (await client.get("/api/bookings", headers=m1.h)).json()["bookings"][0]["booking_id"]
    a = (await client.post(f"/api/bookings/{bid}/cancel-propose", headers=m1.h)).json()["action_id"]
    await client.post(f"/api/actions/{a}/confirm", headers=m1.h)
    st = {r["user_id"]: r["status"] for r in await sql.all("SELECT user_id, status::text FROM class_bookings")}
    assert st[uuid.UUID(m3.id)] == "CONFIRMED" and st[uuid.UUID(m2.id)] == "CANCELLED"


async def test_late_cancel_flag_and_started_class(client, users, sql):
    t = await users.staff("TRAINER"); m = await users.member()
    c = await mk_class(sql, t.id, start_h=1)
    await book(client, m, c)
    bid = (await client.get("/api/bookings", headers=m.h)).json()["bookings"][0]["booking_id"]
    r = await client.post(f"/api/bookings/{bid}/cancel-propose", headers=m.h)
    assert r.json()["is_late_cancel"] is True and "late-cancellation" in r.json()["summary"]
    await sql.run("UPDATE fitness_classes SET start_time = now() - interval '5 minutes', end_time = now() + interval '55 minutes'")
    assert (await client.post(f"/api/bookings/{bid}/cancel-propose", headers=m.h)).status_code == 409


async def test_admin_cancel_class_cancels_bookings_and_notifies(client, users, sql):
    t = await users.staff("TRAINER"); a = await users.staff("ADMIN"); m = await users.member()
    cid = await mk_class(sql, t.id); await book(client, m, cid)
    assert (await client.post(f"/api/admin/classes/{cid}/cancel", headers=m.h)).status_code == 403
    r = await client.post(f"/api/admin/classes/{cid}/cancel", headers=a.h)
    assert r.json()["bookings_cancelled"] == 1
    assert (await sql.val("SELECT count(*) FROM class_bookings WHERE status='CANCELLED'")) == 1
    assert (await client.post("/api/bookings/propose", json={"class_id": cid}, headers=m.h)).status_code == 404
