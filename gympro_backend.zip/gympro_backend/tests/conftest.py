import json, subprocess, uuid, asyncio
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
import asyncpg, pytest, pytest_asyncio, httpx

import pathlib
ROOT = pathlib.Path(__file__).resolve().parent.parent
SU = dict(user="postgres", password="postgres", database="gympro", host="localhost")


@pytest.fixture(scope="session", autouse=True)
def apply_schema():
    cmds = ("psql -v ON_ERROR_STOP=1 -q -d gympro -c 'DROP SCHEMA public CASCADE; CREATE SCHEMA public;' "
            "-c 'CREATE EXTENSION btree_gist; CREATE EXTENSION citext; CREATE EXTENSION pgcrypto;' "
            f"-f {ROOT}/schema.sql -f {ROOT}/roles.sql")
    r = subprocess.run(["su", "postgres", "-c", cmds], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


@pytest_asyncio.fixture(scope="session")
async def su_conn(apply_schema):
    c = await asyncpg.connect(**SU)
    yield c
    await c.close()


@pytest_asyncio.fixture(autouse=True)
async def clean(su_conn):
    await su_conn.execute("TRUNCATE users, gym_settings RESTART IDENTITY CASCADE")
    await su_conn.execute("""INSERT INTO gym_settings (key, value) VALUES ('timezone','"Asia/Kolkata"'),('booking_buffer_minutes','15'),
        ('late_cancel_hours','2'),('pending_action_ttl_min','10'),('min_group_size_reports','5')""")
    from app.auth import limiter
    limiter.hits.clear()
    yield


@pytest_asyncio.fixture(scope="session")
async def client(apply_schema):
    from app.main import app
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://t") as c:
        yield c


class Sql:
    def __init__(self, c): self.c = c
    async def one(self, q, *a): return await self.c.fetchrow(q, *a)
    async def val(self, q, *a): return await self.c.fetchval(q, *a)
    async def all(self, q, *a): return await self.c.fetch(q, *a)
    async def run(self, q, *a): return await self.c.execute(q, *a)


@pytest.fixture
def sql(su_conn): return Sql(su_conn)


PW = "Str0ngPassw0rd!"


class Users:
    def __init__(self, client, sql): self.client, self.sql = client, sql

    async def member(self, name="m", plan="GOLD", profile=False, consent=True, **prof):
        r = await self.client.post("/api/auth/register", json={"email": f"{name}-{uuid.uuid4().hex[:6]}@x.com", "password": PW, "full_name": name})
        assert r.status_code == 201, r.text
        uid, tok = r.json()["user_id"], r.json()["token"]
        if plan:
            await self.sql.run("INSERT INTO memberships (user_id, plan_code, price_paid, end_date) VALUES ($1,$2,10, current_date+30)", uuid.UUID(uid), plan)
        h = {"Authorization": f"Bearer {tok}"}
        if profile:
            body = {"date_of_birth": "1995-05-05", "gender": "MALE", "height_cm": 175, "weight_kg": 75, "activity_level": "MODERATE",
                    "health_data_consent": consent, **prof}
            r = await self.client.put("/api/me/profile", json=body, headers=h)
            assert r.status_code == 200, r.text
        return SimpleNamespace(id=uid, h=h, token=tok)

    async def staff(self, role, name=None):
        from app.auth import make_token, hash_pw
        uid = await self.sql.val("INSERT INTO users (email, password_hash, full_name, role) VALUES ($1,$2,$3,$4::user_role) RETURNING id",
                                 f"{role.lower()}-{uuid.uuid4().hex[:6]}@x.com", await hash_pw(PW), name or role.title(), role)
        if role == "TRAINER":
            await self.sql.run("INSERT INTO trainer_profiles (trainer_id, specializations, certifications) VALUES ($1,'{Fat Loss,HIIT}','{NASM-CPT}')", uid)
        return SimpleNamespace(id=str(uid), h={"Authorization": f"Bearer {make_token(str(uid))}"})


@pytest.fixture
def users(client, sql): return Users(client, sql)


async def mk_class(sql, trainer_id, title="Yoga", start_h=24.0, dur_min=60, cap=10, impact="LOW", cat="YOGA", contra=(), booked=0):
    s = datetime.now(timezone.utc) + timedelta(hours=start_h)
    return str(await sql.val(
        "INSERT INTO fitness_classes (title, trainer_id, category, impact, contraindicated_for, capacity, booked_count, start_time, end_time) "
        "VALUES ($1,$2,$3::class_category,$4::impact_level,$5,$6,$7,$8,$9) RETURNING id",
        title, uuid.UUID(str(trainer_id)), cat, impact, list(contra), cap, booked, s, s + timedelta(minutes=dur_min)))


# ---------- scripted fake LLM (OpenAI-compatible surface)
def msg(content=None, calls=()):
    tc = [SimpleNamespace(id=f"c{i}", function=SimpleNamespace(name=n, arguments=json.dumps(a))) for i, (n, a) in enumerate(calls)]
    return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=content, tool_calls=tc or None))],
                           usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5))


def last_tool_json(kw):
    for m in reversed(kw["messages"]):
        if m["role"] == "tool":
            body = m["content"].split("<tool_result>\n", 1)[1].rsplit("\n</tool_result>", 1)[0]
            return json.loads(body.replace("&lt;", "<"))
    return None


def envelope(agent, status="OK", text_="ok", **kw):
    return json.dumps({"agent": agent, "schema_version": "2.0", "status": status, "data": kw.pop("data", {}), "user_message": text_,
                       "missing_fields": [], "confirmation": kw.pop("confirmation", {}), "safety": kw.pop("safety", {"flags": [], "escalation": None}),
                       "citations": [], "confidence": 0.9})


class FakeLLM:
    def __init__(self, script):
        self.script, self.calls = list(script), []
        self.chat = SimpleNamespace(completions=self)

    async def create(self, **kw):
        self.calls.append(kw)
        step = self.script.pop(0)
        return step(kw) if callable(step) else step


@pytest.fixture
def use_llm(monkeypatch):
    def _set(script):
        fake = FakeLLM(script)
        from app import agents
        monkeypatch.setattr(agents, "get_llm", lambda: fake)
        return fake
    return _set
