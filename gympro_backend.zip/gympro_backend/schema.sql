-- Extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;     -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS btree_gist;   -- exclusion constraints on uuid + ranges
CREATE EXTENSION IF NOT EXISTS citext;       -- case-insensitive email

-- 1. Enum types
CREATE TYPE user_role           AS ENUM ('MEMBER', 'TRAINER', 'ADMIN');
CREATE TYPE gender_type         AS ENUM ('MALE', 'FEMALE', 'OTHER', 'UNSPECIFIED');
CREATE TYPE fitness_goal_type   AS ENUM ('FAT_LOSS', 'MUSCLE_GAIN', 'ENDURANCE', 'REHABILITATION', 'MAINTENANCE');
CREATE TYPE fitness_level_type  AS ENUM ('BEGINNER', 'INTERMEDIATE', 'ADVANCED');
CREATE TYPE class_category      AS ENUM ('HIIT', 'YOGA', 'PILATES', 'SPIN', 'STRENGTH', 'ZUMBA', 'SWIMMING', 'RECOVERY');
CREATE TYPE class_status        AS ENUM ('SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');
CREATE TYPE booking_status      AS ENUM ('CONFIRMED', 'WAITLISTED', 'CANCELLED', 'ATTENDED', 'NO_SHOW');
CREATE TYPE membership_status   AS ENUM ('ACTIVE', 'EXPIRED', 'PENDING', 'CANCELLED');
CREATE TYPE billing_cycle_type  AS ENUM ('MONTHLY', 'ANNUAL');
CREATE TYPE action_type         AS ENUM ('BOOK_CLASS', 'CANCEL_BOOKING', 'JOIN_WAITLIST', 'CHANGE_PLAN', 'RENEW_PLAN', 'SAVE_NUTRITION_PLAN');
CREATE TYPE action_status       AS ENUM ('PENDING', 'CONFIRMED', 'EXECUTED', 'EXPIRED', 'REJECTED', 'FAILED');
CREATE TYPE impact_level        AS ENUM ('LOW', 'MODERATE', 'HIGH');

-- 2. Global settings (gym timezone, buffers, policies): single source of truth for prompts
CREATE TABLE gym_settings (
    key        VARCHAR(80) PRIMARY KEY,
    value      JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO gym_settings (key, value) VALUES
  ('timezone',               '"Asia/Kolkata"'),
  ('booking_buffer_minutes', '15'),
  ('late_cancel_hours',      '2'),
  ('pending_action_ttl_min', '10'),
  ('min_group_size_reports', '5');

-- 3. Users
CREATE TABLE users (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email         CITEXT NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    role          user_role NOT NULL DEFAULT 'MEMBER',
    locale        VARCHAR(10) NOT NULL DEFAULT 'en',
    timezone      VARCHAR(64),                       -- NULL = gym default
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at    TIMESTAMPTZ
);

-- 4. Trainer profiles + verified reviews
CREATE TABLE trainer_profiles (
    trainer_id      UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    specializations TEXT[] NOT NULL DEFAULT '{}',
    certifications  TEXT[] NOT NULL DEFAULT '{}',
    certs_verified_at TIMESTAMPTZ,                   -- NULL = unverified, must not be advertised
    bio             TEXT,
    rating          NUMERIC(3,2) CHECK (rating BETWEEN 1.0 AND 5.0),   -- NULL until first review
    review_count    INT NOT NULL DEFAULT 0 CHECK (review_count >= 0),
    hourly_rate     NUMERIC(10,2) NOT NULL DEFAULT 50.00 CHECK (hourly_rate >= 0),
    accepting_clients BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE trainer_reviews (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trainer_id UUID NOT NULL REFERENCES trainer_profiles(trainer_id) ON DELETE CASCADE,
    member_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    rating     SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment    TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (trainer_id, member_id)
);

-- 5. Member profiles & biometrics (health data: consent-gated, RLS-protected)
CREATE TABLE member_profiles (
    user_id          UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    date_of_birth    DATE NOT NULL,                  -- age derived; never store a drifting integer
    gender           gender_type NOT NULL DEFAULT 'UNSPECIFIED',
    height_cm        NUMERIC(5,2) NOT NULL CHECK (height_cm BETWEEN 100 AND 250),
    weight_kg        NUMERIC(5,2) NOT NULL CHECK (weight_kg BETWEEN 25 AND 350),
    experience_level fitness_level_type NOT NULL DEFAULT 'BEGINNER',
    goal             fitness_goal_type NOT NULL DEFAULT 'MAINTENANCE',
    known_injuries   TEXT[] NOT NULL DEFAULT '{}',   -- normalized codes: KNEE, LOWER_BACK, SHOULDER ...
    allergies        TEXT[] NOT NULL DEFAULT '{}',   -- HARD constraint for nutrition agent
    dietary_preference VARCHAR(50),
    is_pregnant      BOOLEAN,                        -- NULL = not provided
    medical_clearance BOOLEAN NOT NULL DEFAULT FALSE,-- member confirmed doctor clearance / PAR-Q done
    activity_level   VARCHAR(20) NOT NULL DEFAULT 'LIGHT' CHECK (activity_level IN ('SEDENTARY','LIGHT','MODERATE','VERY_ACTIVE')),
    daily_step_goal  INT NOT NULL DEFAULT 10000,
    daily_calorie_burn_goal INT NOT NULL DEFAULT 500,
    health_data_consent_at TIMESTAMPTZ,              -- required before Health/Nutrition agents read this row
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
-- BMR / TDEE are computed by tools at read time (they change with weight/age); not stored.

-- 6. Membership plans (single source of truth) + subscriptions
CREATE TABLE membership_plans (
    code            VARCHAR(20) PRIMARY KEY,         -- SILVER | GOLD | PLATINUM
    display_name    VARCHAR(50) NOT NULL,
    price_monthly   NUMERIC(10,2) NOT NULL CHECK (price_monthly >= 0),
    price_annual    NUMERIC(10,2),
    currency        CHAR(3) NOT NULL DEFAULT 'USD',
    perks           JSONB NOT NULL,                  -- {"group_classes_per_month": 4|null, "pt_sessions_per_month": 0, ...}
    sort_order      INT NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE
);
INSERT INTO membership_plans (code, display_name, price_monthly, perks, sort_order) VALUES
 ('SILVER',   'Silver',   39.00,  '{"group_classes_per_month":4,"pt_sessions_per_month":0,"nutrition_consult":false,"spa":false}', 1),
 ('GOLD',     'Gold',     79.00,  '{"group_classes_per_month":null,"pt_sessions_per_month":2,"nutrition_consult":false,"spa":false}', 2),
 ('PLATINUM', 'Platinum', 129.00, '{"group_classes_per_month":null,"pt_sessions_per_month":5,"nutrition_consult":true,"spa":true}', 3);

CREATE TABLE memberships (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_code     VARCHAR(20) NOT NULL REFERENCES membership_plans(code),
    status        membership_status NOT NULL DEFAULT 'ACTIVE',
    billing_cycle billing_cycle_type NOT NULL DEFAULT 'MONTHLY',
    price_paid    NUMERIC(10,2) NOT NULL CHECK (price_paid >= 0),
    start_date    DATE NOT NULL DEFAULT CURRENT_DATE,
    end_date      DATE NOT NULL,
    auto_renew    BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_membership_dates CHECK (end_date > start_date)
);
CREATE UNIQUE INDEX uq_one_active_membership ON memberships (user_id) WHERE status = 'ACTIVE';

-- 7. Fitness classes
CREATE TABLE fitness_classes (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title          VARCHAR(120) NOT NULL,
    trainer_id     UUID NOT NULL REFERENCES trainer_profiles(trainer_id),
    category       class_category NOT NULL,
    impact         impact_level NOT NULL DEFAULT 'MODERATE',   -- richer than a boolean; drives injury filtering
    contraindicated_for TEXT[] NOT NULL DEFAULT '{}',          -- e.g. {KNEE, LOWER_BACK}
    min_level      fitness_level_type NOT NULL DEFAULT 'BEGINNER',
    est_calories_burned INT NOT NULL DEFAULT 400 CHECK (est_calories_burned >= 0),
    est_steps      INT NOT NULL DEFAULT 0 CHECK (est_steps >= 0),
    capacity       INT NOT NULL CHECK (capacity > 0),
    booked_count   INT NOT NULL DEFAULT 0,
    start_time     TIMESTAMPTZ NOT NULL,
    end_time       TIMESTAMPTZ NOT NULL,
    status         class_status NOT NULL DEFAULT 'SCHEDULED',
    CONSTRAINT chk_time_window CHECK (end_time > start_time),
    CONSTRAINT chk_capacity    CHECK (booked_count BETWEEN 0 AND capacity),
    -- a trainer cannot teach two overlapping non-cancelled classes
    CONSTRAINT excl_trainer_overlap EXCLUDE USING gist (
        trainer_id WITH =,
        tstzrange(start_time, end_time) WITH &&
    ) WHERE (status <> 'CANCELLED')
);

-- 8. Bookings (FIFO waitlist via identity sequence)
CREATE TABLE class_bookings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    class_id        UUID NOT NULL REFERENCES fitness_classes(id) ON DELETE CASCADE,
    status          booking_status NOT NULL DEFAULT 'CONFIRMED',
    waitlist_seq    BIGINT GENERATED ALWAYS AS IDENTITY,       -- FIFO order; position = rank within class
    idempotency_key UUID UNIQUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    cancelled_at    TIMESTAMPTZ
);
-- Only one ACTIVE (confirmed or waitlisted) booking per user per class; unlimited historical rows
CREATE UNIQUE INDEX uq_active_booking ON class_bookings (user_id, class_id)
    WHERE status IN ('CONFIRMED', 'WAITLISTED');
CREATE INDEX idx_waitlist_fifo ON class_bookings (class_id, waitlist_seq) WHERE status = 'WAITLISTED';

-- Reconciliation view: detect drift between booked_count and reality
CREATE VIEW v_class_occupancy AS
SELECT c.id, c.title, c.capacity, c.booked_count,
       COUNT(b.*) FILTER (WHERE b.status IN ('CONFIRMED','ATTENDED')) AS actual_confirmed,
       COUNT(b.*) FILTER (WHERE b.status = 'WAITLISTED')              AS waitlist_size
FROM fitness_classes c LEFT JOIN class_bookings b ON b.class_id = c.id
GROUP BY c.id;

-- 9. Telemetry
CREATE TABLE daily_health_logs (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id                UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    log_date               DATE NOT NULL,
    steps_walked           INT NOT NULL DEFAULT 0 CHECK (steps_walked >= 0),
    active_calories_burned INT NOT NULL DEFAULT 0 CHECK (active_calories_burned >= 0),
    water_intake_ml        INT NOT NULL DEFAULT 0 CHECK (water_intake_ml >= 0),
    hours_slept            NUMERIC(3,1) CHECK (hours_slept BETWEEN 0 AND 24),  -- NULL = not logged (no fake 7.5 default)
    wearable_data          JSONB NOT NULL DEFAULT '{}'::jsonb,
    UNIQUE (user_id, log_date)
);

-- 10. Nutrition plans
CREATE TABLE nutrition_plans (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id            UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dietary_preference VARCHAR(50) NOT NULL,
    target_calories    INT NOT NULL CHECK (target_calories BETWEEN 800 AND 6000),
    protein_grams      INT NOT NULL CHECK (protein_grams >= 0),
    carb_grams         INT NOT NULL CHECK (carb_grams >= 0),
    fat_grams          INT NOT NULL CHECK (fat_grams >= 0),
    meal_plan_details  JSONB NOT NULL,
    prompt_version     VARCHAR(20) NOT NULL,                     -- reproducibility
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. Pending actions: the confirmation boundary between LLM and state change
CREATE TABLE pending_actions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    run_id        UUID,
    type          action_type NOT NULL,
    payload       JSONB NOT NULL,                  -- validated by Pydantic before insert
    summary       TEXT NOT NULL,                   -- human-readable, shown on the confirm card
    status        action_status NOT NULL DEFAULT 'PENDING',
    result        JSONB,
    expires_at    TIMESTAMPTZ NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    executed_at   TIMESTAMPTZ
);
CREATE INDEX idx_pending_user ON pending_actions (user_id, status, expires_at);

-- 12. Notification outbox (transactional) + inbox
CREATE TABLE notification_outbox (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    channel     VARCHAR(20) NOT NULL DEFAULT 'IN_APP',          -- IN_APP | EMAIL | PUSH | SMS
    template    VARCHAR(60) NOT NULL,
    params      JSONB NOT NULL,
    send_after  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    sent_at     TIMESTAMPTZ,
    attempts    INT NOT NULL DEFAULT 0,
    dedupe_key  VARCHAR(120) UNIQUE
);
CREATE TABLE notifications (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title      VARCHAR(150) NOT NULL,
    message    TEXT NOT NULL,
    is_read    BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. Agent observability + prompt registry
CREATE TABLE prompt_versions (
    agent       VARCHAR(40) NOT NULL,
    version     VARCHAR(20) NOT NULL,              -- semver
    sha256      CHAR(64) NOT NULL,
    eval_score  NUMERIC(5,2),                      -- last passing eval run
    released_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (agent, version)
);
CREATE TABLE agent_runs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID REFERENCES users(id) ON DELETE SET NULL,
    trace_id      VARCHAR(64) NOT NULL,
    query_redacted TEXT,                           -- PII-scrubbed
    plan          JSONB,
    final_status  VARCHAR(20),
    prompt_versions JSONB,                         -- {"SCHEDULE":"2.1.0", ...}
    model         VARCHAR(80),
    tokens_in     INT, tokens_out INT, latency_ms INT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE agent_tool_calls (
    id          BIGSERIAL PRIMARY KEY,
    run_id      UUID NOT NULL REFERENCES agent_runs(id) ON DELETE CASCADE,
    agent       VARCHAR(40) NOT NULL,
    tool        VARCHAR(60) NOT NULL,
    args_redacted JSONB,
    ok          BOOLEAN NOT NULL,
    error_code  VARCHAR(40),
    latency_ms  INT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE audit_log (
    id         BIGSERIAL PRIMARY KEY,
    actor_id   UUID, action VARCHAR(60) NOT NULL, entity VARCHAR(60), entity_id UUID,
    details    JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_classes_schedule   ON fitness_classes (start_time, status);
CREATE INDEX idx_classes_trainer    ON fitness_classes (trainer_id, start_time);
CREATE INDEX idx_bookings_user      ON class_bookings (user_id, status);
CREATE INDEX idx_health_user_date   ON daily_health_logs (user_id, log_date DESC);
CREATE INDEX idx_outbox_due         ON notification_outbox (send_after) WHERE sent_at IS NULL;
CREATE INDEX idx_runs_user_time     ON agent_runs (user_id, created_at DESC);

-- Row-Level Security: defense in depth if an application bug leaks a query.
-- The API sets:  SET LOCAL app.user_id = '<jwt sub>';  app.role = 'MEMBER' | ...
ALTER TABLE member_profiles     ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_health_logs   ENABLE ROW LEVEL SECURITY;
ALTER TABLE class_bookings      ENABLE ROW LEVEL SECURITY;
ALTER TABLE nutrition_plans     ENABLE ROW LEVEL SECURITY;
ALTER TABLE pending_actions     ENABLE ROW LEVEL SECURITY;

CREATE POLICY own_rows ON member_profiles   USING (user_id = nullif(current_setting('app.user_id', true), '')::uuid);
CREATE POLICY own_rows ON daily_health_logs USING (user_id = nullif(current_setting('app.user_id', true), '')::uuid);
CREATE POLICY own_rows ON nutrition_plans   USING (user_id = nullif(current_setting('app.user_id', true), '')::uuid);
CREATE POLICY own_rows ON pending_actions   USING (user_id = nullif(current_setting('app.user_id', true), '')::uuid);

-- Least-privilege DB roles
-- gympro_app       : read/write on operational tables, used by the API
-- gympro_analytics : SELECT only on analytics views (v_*), statement_timeout = 5s, used by Analytics tools

-- RLS (split policies): members see/modify own rows; SYSTEM (server-internal, set only in code) may act on any
-- row inside a transaction; ADMIN may only READ bookings (aggregates).
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY own_rows ON notifications USING (user_id = nullif(current_setting('app.user_id', true), '')::uuid
                                              OR current_setting('app.role', true) = 'SYSTEM');
CREATE POLICY own_rows ON class_bookings
    USING (user_id = nullif(current_setting('app.user_id', true), '')::uuid OR current_setting('app.role', true) = 'SYSTEM');
CREATE POLICY admin_read ON class_bookings FOR SELECT USING (current_setting('app.role', true) = 'ADMIN');
CREATE POLICY system_all ON member_profiles USING (current_setting('app.role', true) = 'SYSTEM');
CREATE POLICY system_all ON pending_actions USING (current_setting('app.role', true) = 'SYSTEM');
CREATE POLICY system_all ON nutrition_plans USING (current_setting('app.role', true) = 'SYSTEM');
CREATE POLICY system_all ON daily_health_logs USING (current_setting('app.role', true) = 'SYSTEM');
ALTER TABLE class_bookings FORCE ROW LEVEL SECURITY;
ALTER TABLE member_profiles FORCE ROW LEVEL SECURITY;
ALTER TABLE daily_health_logs FORCE ROW LEVEL SECURITY;
ALTER TABLE nutrition_plans FORCE ROW LEVEL SECURITY;
ALTER TABLE pending_actions FORCE ROW LEVEL SECURITY;
ALTER TABLE notifications FORCE ROW LEVEL SECURITY;
